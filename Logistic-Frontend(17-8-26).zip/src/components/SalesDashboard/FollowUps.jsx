import React, { useState, useEffect } from 'react';
import {
  Plus, X, Bell, ChevronDown, Check,
  Phone, Mail, Calendar, CheckCircle, AlertCircle, Clock
} from 'lucide-react';
import { crmRepository } from '../../services/crmRepository';
import { crmStore } from '../../services/crmStore';
import { useAuth } from '../../context/AuthContext';
import { getSalesReps } from '../../services/api';

export default function FollowUps() {
  const { user } = useAuth();
  // Database States
  const [followups, setFollowups] = useState([]);
  const [leads, setLeads] = useState([]);
  const [salesReps, setSalesReps] = useState([]);
  const [selectedRepFilter, setSelectedRepFilter] = useState('ALL');

  // UI States
  const [activeFilter, setActiveFilter] = useState('ALL');

  // Modal States
  const [showAddModal, setShowAddModal] = useState(false);
  const [modalForm, setModalForm] = useState({
    leadId: '',
    type: 'Call',
    priority: 'Medium',
    dueDate: new Date().toISOString().split('T')[0],
    dueTime: '10:00 AM',
    notes: ''
  });

  // Toast
  const [toast, setToast] = useState(null);

  // Subscribe to crmStore
  useEffect(() => {
    // Sync with database
    crmRepository.syncWithBackend();

    getSalesReps().then(res => {
      if (res.data?.success && Array.isArray(res.data.data)) {
        setSalesReps(res.data.data);
      }
    }).catch(err => console.error('Error fetching reps in follow-ups:', err));

    const syncDb = () => {
      const db = crmRepository.getCrmDatabase();
      setFollowups(db.crmFollowups || []);
      setLeads(crmRepository.getLeads());
      const reps = crmRepository.getSalesReps();
      if (reps?.length) setSalesReps(reps);
    };
    syncDb();
    const unsubscribe = crmStore.subscribe(syncDb);
    return () => unsubscribe();
  }, []);

  // Sync modal default lead
  useEffect(() => {
    if (leads.length > 0) {
      setModalForm(prev => ({ ...prev, leadId: prev.leadId || leads[0].id }));
    }
  }, [leads]);

  // Toast auto-clear
  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(t);
    }
  }, [toast]);

  const repsList = ['Alex Wright', 'Sarah K.', 'Michael Scott', 'Jan Levinson', 'Ryan Howard'];

  const filters = ['ALL', 'PENDING', 'COMPLETED', 'MISSED'];

  const getTypeIcon = (type) => {
    if (type === 'Call') return { icon: <Phone className="w-5 h-5" />, bg: 'bg-amber-50 text-amber-500 border border-amber-100' };
    if (type === 'Email') return { icon: <Mail className="w-5 h-5" />, bg: 'bg-indigo-50 text-indigo-400 border border-indigo-100' };
    if (type === 'Meeting') return { icon: <Calendar className="w-5 h-5" />, bg: 'bg-fuchsia-50 text-fuchsia-400 border border-fuchsia-100' };
    return { icon: <CheckCircle className="w-5 h-5" />, bg: 'bg-slate-50 text-slate-400 border border-slate-100' };
  };

  const getStatusStyle = (status) => {
    if (status === 'Completed') return 'bg-emerald-50 border border-emerald-200 text-emerald-700';
    if (status === 'Missed') return 'bg-rose-50 border border-rose-200 text-rose-700';
    return 'bg-amber-50 border border-amber-200 text-amber-700';
  };

  // Handle complete follow-up
  const handleMarkCompleted = async (followupId) => {
    await crmRepository.updateFollowUpTask(followupId, { status: 'Completed' });
    setToast({ text: 'Follow-up task marked as completed.' });
  };

  // Handle add task form submit
  const handleAddSubmit = async (e) => {
    e.preventDefault();
    if (!modalForm.notes || !modalForm.notes.trim()) return;

    if (!modalForm.leadId) {
      alert('Please select a lead to associate this task with.');
      return;
    }

    const lead = leads.find(l => l.id === modalForm.leadId);
    if (!lead) return;

    await crmRepository.createFollowUpTask(modalForm);

    setToast({ text: `Follow-up task logged successfully.` });
    setShowAddModal(false);
    setModalForm({
      leadId: '',
      type: 'Call',
      priority: 'Medium',
      dueDate: new Date().toISOString().split('T')[0],
      dueTime: '10:00 AM',
      notes: ''
    });
  };

  // Filter and role-filter followups
  const filteredFollowups = followups.filter(f => {
    const lead = leads.find(l => l.id === f.leadId);
    if (user?.accessProfile === 'SALES_REP') {
      if (lead && lead.repId !== user?.id && lead.rep !== user?.name) return false;
    }
    if (selectedRepFilter !== 'ALL' && lead) {
      if (lead.repId !== selectedRepFilter && lead.rep !== selectedRepFilter) return false;
    }

    // Status tab filter
    if (activeFilter === 'PENDING') return f.status === 'Pending';
    if (activeFilter === 'COMPLETED') return f.status === 'Completed';
    if (activeFilter === 'MISSED') return f.status === 'Missed';
    return true;
  });

  return (
    <div className="flex-grow bg-[#F8FAFC] p-6 space-y-6 overflow-y-auto scrollbar-none [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] w-full text-left font-sans flex flex-col h-full min-h-0">

      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2.5 px-4 py-3 bg-slate-900 text-white rounded-xl shadow-xl text-xs font-semibold animate-slide-in">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.5)]"></span>
          {toast.text}
        </div>
      )}

      {/* Header Container */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shrink-0 bg-white border border-slate-200/80 rounded-2xl p-5 shadow-xs">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight leading-none">
              Follow-Ups
            </h1>
            <div className="bg-[#FEF3C7] text-[#92400E] px-2.5 py-1 text-[9px] rounded-lg border border-[#FDE68A] uppercase font-black leading-none flex flex-col items-center justify-center shrink-0">
              <span className="text-[7px] text-[#B45309] font-bold tracking-wider mb-0.5">Enterprise</span>
              <span>Logistics</span>
            </div>
            <span className="flex items-center gap-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] px-2.5 py-1 rounded-full font-extrabold shrink-0">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Shift: Sales Active
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-2 font-medium">
            Scheduled prospect engagements, reminder queues, and activity tracking.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap sm:flex-nowrap">
          {/* Authenticated Identity Indicator */}
          <div className="flex items-center gap-2 bg-slate-100 border border-slate-200 px-3.5 py-2 rounded-xl text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <div>
              <span className="text-[9px] text-slate-400 font-bold block uppercase tracking-wider leading-none">Logged In</span>
              <strong className="text-slate-900 font-extrabold text-[11px] leading-tight block">{user?.name || 'Sales Officer'}</strong>
            </div>
            <span className="ml-1.5 px-2 py-0.5 bg-amber-100 text-amber-900 font-black text-[9px] rounded-md uppercase">
              {user?.role === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : user?.accessProfile || 'SALES_FULL_ACCESS'}
            </span>
          </div>

          {/* Filter by Sales Rep (Full Access only) */}
          {(user?.role === 'SUPER_ADMIN' || user?.accessProfile !== 'SALES_REP') && (
            <div className="relative">
              <select
                value={selectedRepFilter}
                onChange={(e) => setSelectedRepFilter(e.target.value)}
                className="bg-white border border-slate-300 text-slate-700 text-xs font-bold px-3 py-2.5 rounded-xl focus:outline-none cursor-pointer shadow-xs hover:border-amber-400 transition-colors"
              >
                <option value="ALL">All Sales Reps</option>
                {salesReps.map(rep => (
                  <option key={rep.id} value={rep.id}>{rep.name || rep.email}</option>
                ))}
              </select>
            </div>
          )}

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white text-xs px-4 py-2.5 rounded-xl font-bold transition-all shadow-xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Schedule Follow-Up
          </button>
        </div>
      </div>

      {/* Tasks Panel */}
      <div className="shrink-0 bg-white border border-slate-200/80 rounded-2xl shadow-xs flex flex-col overflow-hidden">
        {/* Panel Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 shrink-0">
          <div>
            <h2 className="text-[13px] font-black text-slate-900">Sales Follow-Up Tasks Agenda</h2>
            <p className="text-[10px] text-slate-400 font-semibold mt-0.5">
              Track pending calls, touchpoint emails, and administrative check-ins.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Filter Tabs */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              {filters.map((f) => (
                <button
                  key={f}
                  onClick={() => setActiveFilter(f)}
                  className={`px-3 py-1 rounded-lg text-[10px] font-extrabold uppercase transition-all cursor-pointer ${
                    activeFilter === f
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            <button
              onClick={() => {
                setModalForm({
                  leadId: '',
                  type: 'Call',
                  priority: 'Medium',
                  dueDate: new Date().toISOString().split('T')[0],
                  dueTime: '10:00 AM',
                  notes: ''
                });
                setShowAddModal(true);
              }}
              className="flex items-center gap-1.5 text-[#D97706] hover:text-[#B45309] font-extrabold text-[10px] bg-white border border-[#FDE68A] hover:bg-[#FFFBEB] px-3.5 py-2 rounded-xl transition-colors shrink-0 whitespace-nowrap shadow-xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 shrink-0 stroke-[3px]" /> Log Touchpoint Task
            </button>
          </div>
        </div>

        {/* Follow-Up Items List */}
        <div className="p-6 space-y-4">
          {filteredFollowups.map((f) => {
            const { icon, bg } = getTypeIcon(f.type);

            return (
              <div
                key={f.id}
                className="p-5 flex items-center justify-between gap-5 bg-white border border-slate-200/80 rounded-[1.25rem] shadow-sm hover:border-amber-200 transition-colors"
              >
                {/* Icon */}
                <div className={`w-[3.25rem] h-[3.25rem] rounded-2xl flex items-center justify-center shrink-0 ${bg}`}>
                  {icon}
                </div>

                {/* Content */}
                <div className="flex-grow min-w-0 flex flex-col justify-center">
                  <div className="flex items-center gap-3 flex-wrap mb-1.5">
                    <strong className="text-slate-900 font-black text-[13px] leading-none">
                      {f.company}
                    </strong>
                    <span className="text-[9px] text-slate-600 bg-slate-50 border border-slate-100 px-2.5 py-0.5 rounded font-mono font-bold tracking-wide">
                      {f.dueDate} • {f.dueTime}
                    </span>
                    {f.priority && (
                      <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded border ${
                        f.priority === 'High' ? 'bg-rose-50 text-rose-600 border-rose-200' :
                        f.priority === 'Low' ? 'bg-slate-50 text-slate-600 border-slate-200' :
                        'bg-amber-50 text-amber-700 border-amber-200'
                      }`}>
                        {f.priority}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 font-semibold leading-normal">
                    Contact: <span className="text-slate-700">{f.contact}</span> • Task: {f.notes}
                  </p>
                </div>

                {/* Status Badge + Action */}
                <div className="flex flex-col items-end gap-2 shrink-0">
                  {f.status === 'Completed' ? (
                    <span className="px-2.5 py-1 rounded-md text-[8px] font-black uppercase tracking-widest text-emerald-600 bg-emerald-50 border border-emerald-200 leading-none">
                      COMPLETED
                    </span>
                  ) : f.status === 'Missed' ? (
                    <div className="flex flex-col items-end gap-1.5">
                      <span className="px-2.5 py-1 rounded-md text-[8px] font-black uppercase tracking-widest text-rose-600 bg-rose-50 border border-rose-200 leading-none">
                        MISSED
                      </span>
                      <button
                        onClick={() => handleMarkCompleted(f.id)}
                        className="flex items-center gap-1 text-[9px] font-extrabold text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 px-2 py-1 rounded-lg transition-colors cursor-pointer"
                      >
                        <Check className="w-3 h-3 stroke-[3px]" /> Mark Done
                      </button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-end gap-1.5">
                      <span className="px-2.5 py-1 rounded-md text-[8px] font-black uppercase tracking-widest text-amber-700 bg-amber-50 border border-amber-200 leading-none">
                        PENDING
                      </span>
                      <button
                        onClick={() => handleMarkCompleted(f.id)}
                        className="flex items-center gap-1 text-[9px] font-extrabold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2.5 py-1 rounded-lg transition-colors cursor-pointer shadow-3xs active:scale-95"
                      >
                        <Check className="w-3 h-3 stroke-[3px]" /> Mark Done
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {filteredFollowups.length === 0 && (
            <div className="py-16 text-center text-slate-400 font-bold text-xs uppercase tracking-wider select-none">
              No follow-up tasks in this view.
            </div>
          )}
        </div>
      </div>

      {/* Log Task Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-[999] flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl w-full max-w-[500px] shadow-2xl overflow-hidden animate-slide-in">
            {/* Header */}
            <div className="px-6 py-5 flex justify-between items-center border-b border-slate-100">
              <h2 className="text-[17px] font-bold text-slate-900">Create New Task</h2>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600 transition-colors cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body Form */}
            <form onSubmit={handleAddSubmit} className="px-6 py-6 space-y-5">
              
              {/* Task Title */}
              <div className="space-y-2">
                <label className="block text-[11px] font-black text-slate-500 uppercase tracking-wider">TASK TITLE</label>
                <input
                  type="text"
                  required
                  value={modalForm.notes}
                  onChange={(e) => setModalForm({ ...modalForm, notes: e.target.value })}
                  placeholder="e.g. Verify DOT registrations"
                  className="w-full border border-slate-200 rounded-xl px-4 py-3 text-[13px] font-semibold text-slate-700 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-colors"
                />
              </div>

              {/* Associate Lead (Optional) */}
              <div className="space-y-2">
                <label className="block text-[11px] font-black text-slate-500 uppercase tracking-wider">ASSOCIATE WITH LEAD (OPTIONAL)</label>
                <select
                  value={modalForm.leadId}
                  onChange={(e) => setModalForm({ ...modalForm, leadId: e.target.value })}
                  className="w-full border border-slate-200 rounded-xl px-4 py-3 text-[13px] font-semibold text-slate-700 focus:outline-none focus:border-amber-400 transition-colors bg-white appearance-auto cursor-pointer"
                >
                  <option value="">-- General / No Specific Lead --</option>
                  {leads.map(l => (
                    <option key={l.id} value={l.id}>{l.company} ({l.name})</option>
                  ))}
                </select>
              </div>

              {/* 3 Columns */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Task Type */}
                <div className="space-y-2">
                  <label className="block text-[11px] font-black text-slate-500 uppercase tracking-wider">TASK TYPE</label>
                  <select
                    value={modalForm.type}
                    onChange={(e) => setModalForm({ ...modalForm, type: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-4 py-3 text-[13px] font-semibold text-slate-700 focus:outline-none focus:border-amber-400 transition-colors bg-white appearance-auto cursor-pointer"
                  >
                    <option value="Call">Phone Call</option>
                    <option value="Meeting">Meeting</option>
                    <option value="Email">Email</option>
                    <option value="Proposal">Proposal</option>
                    <option value="Follow-up">Follow-up</option>
                    <option value="Training">Training</option>
                  </select>
                </div>

                {/* Due Date */}
                <div className="space-y-2">
                  <label className="block text-[11px] font-black text-slate-500 uppercase tracking-wider">DUE DATE</label>
                  <input
                    type="date"
                    required
                    value={modalForm.dueDate}
                    onChange={(e) => setModalForm({ ...modalForm, dueDate: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-4 py-3 text-[13px] font-semibold text-slate-700 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-colors cursor-pointer"
                  />
                </div>

                {/* Priority */}
                <div className="space-y-2">
                  <label className="block text-[11px] font-black text-slate-500 uppercase tracking-wider">PRIORITY</label>
                  <select
                    value={modalForm.priority}
                    onChange={(e) => setModalForm({ ...modalForm, priority: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-4 py-3 text-[13px] font-semibold text-slate-700 focus:outline-none focus:border-amber-400 transition-colors bg-white appearance-auto cursor-pointer"
                  >
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#FFB020] hover:bg-brand-600 text-slate-900 font-extrabold text-[14px] py-3.5 rounded-xl shadow-[0_4px_15px_rgba(255,176,32,0.4)] transition-all mt-2 cursor-pointer active:scale-95"
              >
                Create Task checklist
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
