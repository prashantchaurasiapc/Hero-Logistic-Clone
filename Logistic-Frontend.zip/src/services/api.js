import axios from 'axios';

const api = axios.create({
  // In development, this points to the backend running on localhost:5000
  // In production, it would be the real API URL
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api/v1',
  withCredentials: true, // Crucial for sending HttpOnly cookies
  headers: {
    'Content-Type': 'application/json',
  },
});

export const getSuperAdminDashboard = () => {
  return api.get('/super-admin/dashboard');
};

// Sales / CRM APIs
export const getSalesDashboardSummary = () => api.get('/sales-dashboard/summary');
export const getLeads = () => api.get('/leads');
export const getLead = (id) => api.get(`/leads/${id}`);
export const createLead = (data) => api.post('/leads', data);
export const updateLead = (id, data) => api.put(`/leads/${id}`, data);
export const deleteLead = (id) => api.delete(`/leads/${id}`);
export const createDemoBooking = (data) => api.post('/demo-bookings', data);
export const createProposal = (data) => api.post('/proposals', data);
export const updateProposal = (id, data) => api.put(`/proposals/${id}`, data);
export const createFollowUpTask = (data) => api.post('/follow-up-tasks', data);
export const updateFollowUpTask = (id, data) => api.put(`/follow-up-tasks/${id}`, data);
export const createSalesActivity = (data) => api.post('/sales-activitys', data);
export const convertLeadToCompany = (id, data) => api.post(`/leads/${id}/convert-to-company`, data);

// Dispatcher APIs
export const getLoads = () => api.get('/loads');
export const createLoad = (data) => api.post('/loads', data);
export const updateLoad = (id, data) => api.put(`/loads/${id}`, data);
export const deleteLoad = (id) => api.delete(`/loads/${id}`);
export const getDrivers = () => api.get('/drivers');
export const getVehicles = () => api.get('/vehicles');
export const getCustomersList = () => api.get('/customers');
export const createCustomer = (data) => api.post('/customers', data);
export const updateCustomer = (id, data) => api.put(`/customers/${id}`, data);
export const deleteCustomer = (id) => api.delete(`/customers/${id}`);

// Request Interceptor to add access token header dynamically
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response Interceptor for handling 401 Unauthorized
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response && error.response.status === 401) {
      const originalRequest = error.config;
      // Skip interceptor loop for auth check and logout endpoints
      if (originalRequest.url && (originalRequest.url.includes('/auth/me') || originalRequest.url.includes('/auth/logout') || originalRequest.url.includes('/auth/login'))) {
        return Promise.reject(error);
      }
      
      // If we get a 401 on a normal request, it means the token is invalid or expired
      window.dispatchEvent(new CustomEvent('auth:unauthorized'));
    }
    return Promise.reject(error);
  }
);

export default api;
