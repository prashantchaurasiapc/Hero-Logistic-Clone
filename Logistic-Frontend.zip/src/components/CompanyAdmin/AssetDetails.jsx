import React, { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ChevronRight, CheckCircle2, ChevronDown, Edit, ArrowLeft,
  FileText, Calendar, Clock, MapPin, Building, Shield, AlertTriangle,
  Wrench, CheckCircle, Package, User, Plus, Download, Tag, DollarSign,
  QrCode, MoreHorizontal, Activity, ArrowRight, Copy, Check, Eye,
  BarChart2, FileCheck, Info, Layers, RefreshCw, X, Filter, Search,
  Users, AlertCircle, TrendingUp, RotateCcw, FileSpreadsheet, PlusCircle
, File as FileIcon, ChevronLeft, MoreVertical, Zap, Settings, ShieldAlert, Upload, Code , Printer } from 'lucide-react';


const assetDocuments = [
  { id: 1, name: 'Registration Certificate', file: 'AST-0001_REG.pdf', category: 'Registration', type: 'Registration', issueDate: '15 Mar 2022', expiryDate: '15 Mar 2027', status: 'Active', expiryStatus: 'Compliant', uploader: 'Sarah Mitchell', uploadDate: '15 Mar 2022' },
  { id: 2, name: 'Service & Maintenance Record', file: 'AST-0001_SRV.pdf', category: 'Maintenance', type: 'Service Record', issueDate: '24 May 2025', expiryDate: '24 Jun 2025', status: 'Active', expiryStatus: 'Expiring Soon', uploader: 'James Patel', uploadDate: '24 May 2025' },
  { id: 3, name: 'Annual Inspection Report', file: 'AST-0001_INSP.pdf', category: 'Inspection', type: 'Inspection Report', issueDate: '24 Aug 2024', expiryDate: '24 Aug 2025', status: 'Active', expiryStatus: 'Expiring Soon', uploader: 'Robert Taylor', uploadDate: '24 Aug 2024' },
  { id: 4, name: 'Operating Licence', file: 'AST-0001_LIC.pdf', category: 'Licence', type: 'Operating Licence', issueDate: '10 Jan 2022', expiryDate: '10 Jan 2026', status: 'Active', expiryStatus: 'Compliant', uploader: 'Sarah Mitchell', uploadDate: '10 Jan 2022' },
  { id: 5, name: 'Insurance Certificate', file: 'AST-0001_INS.pdf', category: 'Insurance', type: 'Insurance', issueDate: '01 Jan 2025', expiryDate: '01 Jan 2026', status: 'Active', expiryStatus: 'Compliant', uploader: 'Sarah Mitchell', uploadDate: '01 Jan 2025' },
  { id: 6, name: 'Load Test Certificate', file: 'AST-0001_LOAD.pdf', category: 'Compliance', type: 'Compliance Certificate', issueDate: '14 Feb 2024', expiryDate: '14 Feb 2025', status: 'Expired', expiryStatus: 'Expired', uploader: 'James Patel', uploadDate: '14 Feb 2024' },
  { id: 7, name: 'Manufacturer Manual', file: 'AST-0001_MAN.pdf', category: 'Other', type: 'Manual', issueDate: '10 Mar 2022', expiryDate: '-', status: 'Active', expiryStatus: 'Not Required', uploader: 'Sarah Mitchell', uploadDate: '10 Mar 2022' },
  { id: 8, name: 'Safety Compliance Checklist', file: 'AST-0001_CHK.pdf', category: 'Compliance', type: 'Checklist', issueDate: '20 May 2025', expiryDate: '-', status: 'Active', expiryStatus: 'Not Required', uploader: 'Robert Taylor', uploadDate: '20 May 2025' },
  { id: 9, name: 'Warranty Certificate', file: 'AST-0001_WTY.pdf', category: 'Warranty', type: 'Warranty', issueDate: '15 Mar 2022', expiryDate: '15 Mar 2023', status: 'Expired', expiryStatus: 'Expired', uploader: 'Sarah Mitchell', uploadDate: '15 Mar 2022' },
];


const mockMaintenanceTasks = [
  { id: 1, task: 'Service & Maintenance', desc: 'Routine full service', type: 'Service', priority: 'High', freq: '250 Hours', lastDate: '24 May 2025', lastHrs: '1,000 Hrs', nextDate: '24 Jun 2025', nextHrs: '1,250 Hrs', status: 'Due Soon', daysRemaining: '18 days', assigned: 'James Patel', role: 'Workshop' },
  { id: 2, task: 'Oil & Filter Change', desc: 'Engine oil and filter', type: 'Service', priority: 'Medium', freq: '250 Hours', lastDate: '24 May 2025', lastHrs: '1,000 Hrs', nextDate: '24 Jun 2025', nextHrs: '1,250 Hrs', status: 'Due Soon', daysRemaining: '18 days', assigned: 'James Patel', role: 'Workshop' },
  { id: 3, task: 'Full Inspection', desc: 'Complete safety inspection', type: 'Inspection', priority: 'High', freq: 'Monthly', lastDate: '24 May 2025', lastHrs: null, nextDate: '24 Jun 2025', nextHrs: null, status: 'Due Soon', daysRemaining: '18 days', assigned: 'Robert Taylor', role: 'Safety Officer' },
  { id: 4, task: 'Hydraulic System Check', desc: 'Check hoses, leaks & pressure', type: 'Inspection', priority: 'Medium', freq: '500 Hours', lastDate: '10 May 2025', lastHrs: '950 Hrs', nextDate: '10 Jul 2025', nextHrs: '1,450 Hrs', status: 'Scheduled', daysRemaining: '34 days', assigned: 'James Patel', role: 'Workshop' },
  { id: 5, task: 'Fork & Mast Inspection', desc: 'Inspect forks, chains & mast', type: 'Inspection', priority: 'Medium', freq: 'Monthly', lastDate: '24 May 2025', lastHrs: null, nextDate: '24 Jun 2025', nextHrs: null, status: 'Scheduled', daysRemaining: '18 days', assigned: 'Robert Taylor', role: 'Safety Officer' },
  { id: 6, task: 'Tyre Check & Pressure', desc: 'Check tyre condition & pressure', type: 'Service', priority: 'Low', freq: 'Monthly', lastDate: '24 May 2025', lastHrs: null, nextDate: '24 Jun 2025', nextHrs: null, status: 'Scheduled', daysRemaining: '18 days', assigned: 'Workshop Team', role: null },
  { id: 7, task: 'Battery Check', desc: 'Check battery, terminals & charge', type: 'Service', priority: 'Low', freq: 'Monthly', lastDate: '10 May 2025', lastHrs: null, nextDate: '10 Jun 2025', nextHrs: null, status: 'Completed', daysRemaining: 'Completed', assigned: 'James Patel', role: 'Workshop' }
];

export default function AssetDetails({ assetData, onBack }) {
  const navigate = useNavigate();
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState('Overview');
  const [activeDocTab, setActiveDocTab] = useState('All Documents');
  const [activeMaintTab, setActiveMaintTab] = useState('Maintenance Schedule');
  const [activeSubTab, setActiveSubTab] = useState('Current Assignment');
  const [isMoreActionsOpen, setIsMoreActionsOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [copiedTag, setCopiedTag] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState({ title: 'Asset Updated', desc: 'Changes saved live.' });
  const [viewAssignmentModal, setViewAssignmentModal] = useState(null);
  const [asgMenuIndex, setAsgMenuIndex] = useState(null);
  const [viewMaintTaskModal, setViewMaintTaskModal] = useState(null);
  const [maintMenuIndex, setMaintMenuIndex] = useState(null);
  const [maintTasksList, setMaintTasksList] = useState(mockMaintenanceTasks);
  const [viewDocModal, setViewDocModal] = useState(null);
  const [editDocModal, setEditDocModal] = useState(null);
  const [docMenuIndex, setDocMenuIndex] = useState(null);
  const [documentsList, setDocumentsList] = useState(assetDocuments);
  const [viewCostModal, setViewCostModal] = useState(null);
  const [editCostModal, setEditCostModal] = useState(null);
  const [costMenuIndex, setCostMenuIndex] = useState(null);
  const [editAssignmentModal, setEditAssignmentModal] = useState(null);
  const [editMaintTaskModal, setEditMaintTaskModal] = useState(null);

  const triggerToast = (title, desc) => {
    setToastMessage({ title, desc });
    setShowToast(true);
    setTimeout(() => setShowToast(false), 4000);
  };

  // Filter state for assignment history table
  const [assignmentSearch, setAssignmentSearch] = useState('');

  // Costs & Depreciation specific state
  const [activeCostTab, setActiveCostTab] = useState('Cost Overview');
  const [costSearch, setCostSearch] = useState('');
  const [costDateRange, setCostDateRange] = useState('01 Jul 2024 - 30 Jun 2025');
  const [isDatePopoverOpen, setIsDatePopoverOpen] = useState(false);

  // Costs Mock Data
  const [costsList, setCostsList] = useState([
    { date: '24 May 2025', category: 'Maintenance', type: 'Service', desc: 'Service & Maintenance', ref: 'INV-2025-056', loc: 'Sydney Head Office', amount: '$450.00', tax: '$45.00', total: '$495.00', color: 'purple' },
    { date: '24 May 2025', category: 'Maintenance', type: 'Parts', desc: 'Oil Filter & Lubricants', ref: 'INV-2025-057', loc: 'Sydney Head Office', amount: '$120.00', tax: '$12.00', total: '$132.00', color: 'purple' },
    { date: '10 May 2025', category: 'Operating', type: 'Fuel', desc: 'Diesel Fuel', ref: 'FUEL-2025-1021', loc: 'Sydney Head Office', amount: '$200.00', tax: '$20.00', total: '$220.00', color: 'emerald' },
    { date: '25 Apr 2025', category: 'Maintenance', type: 'Repair', desc: 'Hydraulic Pump Repair', ref: 'INV-2025-041', loc: 'Sydney Head Office', amount: '$780.00', tax: '$78.00', total: '$858.00', color: 'purple' },
    { date: '15 Apr 2025', category: 'Operating', type: 'Fuel', desc: 'Diesel Fuel', ref: 'FUEL-2025-0985', loc: 'Sydney Head Office', amount: '$190.00', tax: '$19.00', total: '$209.00', color: 'emerald' },
    { date: '01 Apr 2025', category: 'Insurance', type: 'Insurance', desc: 'Asset Insurance', ref: 'INS-2025-088', loc: 'Sydney Head Office', amount: '$250.00', tax: '$0.00', total: '$250.00', color: 'blue' },
    { date: '31 Mar 2025', category: 'Registration', type: 'Registration', desc: 'Registration Fee', ref: 'REG-2025-033', loc: 'Sydney Head Office', amount: '$91.00', tax: '$9.10', total: '$100.10', color: 'orange' },
    { date: '20 Mar 2025', category: 'Operating', type: 'Fuel', desc: 'Diesel Fuel', ref: 'FUEL-2025-0820', loc: 'Sydney Head Office', amount: '$180.00', tax: '$18.00', total: '$198.00', color: 'emerald' },
    { date: '05 Mar 2025', category: 'Maintenance', type: 'Service', desc: 'Routine Service', ref: 'INV-2025-020', loc: 'Sydney Head Office', amount: '$320.00', tax: '$32.00', total: '$352.00', color: 'purple' },
    { date: '15 Feb 2025', category: 'Operating', type: 'Fuel', desc: 'Diesel Fuel', ref: 'FUEL-2025-0615', loc: 'Sydney Head Office', amount: '$170.00', tax: '$17.00', total: '$187.00', color: 'emerald' },
    { date: '11 Nov 2024', category: 'Other', type: 'Other', desc: 'Safety Equipment', ref: 'INV-2024-211', loc: 'Sydney Head Office', amount: '$50.00', tax: '$5.00', total: '$55.00', color: 'slate' },
  ]);

  // States for More Actions dropdown modals
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [isMaintenanceModalOpen, setIsMaintenanceModalOpen] = useState(false);
  const [isPrintQRModalOpen, setIsPrintQRModalOpen] = useState(false);
  const [isDeactivateModalOpen, setIsDeactivateModalOpen] = useState(false);

  // Asset defaults matching screenshots
  const defaultAsset = {
    id: id || 'AST-0001',
    titleNumber: '8.2',
    name: 'Toyota 8FD25',
    fullName: 'Toyota 8FD25 Forklift',
    category: 'Forklifts',
    categoryBadge: 'Material Handling',
    type: 'Diesel Forklift',
    makeModel: 'Toyota 8FD25',
    year: '2022',
    serialNo: '8FD25-12345',
    serialNumberFull: 'XHD25-12345',
    assetTag: 'AST-0001',
    branch: 'Sydney Head Office',
    location: 'Warehouse 1',
    currentLocation: 'Warehouse 1 - Bay A3',
    assignedTo: 'Warehouse 1',
    status: 'Active',
    condition: 'Good',
    purchaseDate: '15 Mar 2022',
    purchasePrice: '$38,500.00 AUD',
    bookValue: '$26,950.00 AUD',
    supplier: 'Toyota Material Handling',
    warrantyExpiry: '15 Mar 2026',
    warrantyDaysLeft: '(in 243 days)',
    usageType: 'Operational',
    operatingHours: '1,256.5 Hrs',
    odometer: '1,256.5 Hrs',
    nextService: '24 Jun 2025',
    nextServiceDays: '(in 18 days)',
    description: 'General purpose forklift used for warehouse operations including loading, unloading and pallet movement. Fitted with side shift and solid pneumatic tyres.',
    notes: 'Keep forks properly lubricated. Daily pre-start inspection required.',
    image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&auto=format&fit=crop&q=60'
  };

  const initialAsset = { ...defaultAsset, ...(assetData || {}) };
  if (!initialAsset.fullName) initialAsset.fullName = `${initialAsset.name || 'Toyota 8FD25'} Forklift`;
  if (!initialAsset.bookValue) initialAsset.bookValue = '$26,950.00 AUD';
  if (!initialAsset.purchasePrice) initialAsset.purchasePrice = '$38,500.00 AUD';
  if (!initialAsset.purchaseDate) initialAsset.purchaseDate = '15 Mar 2022';
  if (!initialAsset.supplier) initialAsset.supplier = 'Toyota Material Handling';
  if (!initialAsset.operatingHours) initialAsset.operatingHours = '1,256.5 Hrs';
  if (!initialAsset.odometer) initialAsset.odometer = '1,256.5 Hrs';
  if (!initialAsset.serialNumberFull) initialAsset.serialNumberFull = 'XHD25-12345';
  if (!initialAsset.serialNo) initialAsset.serialNo = '8FD25-12345';
  if (!initialAsset.assetTag) initialAsset.assetTag = initialAsset.id || 'AST-0001';
  if (!initialAsset.currentLocation) initialAsset.currentLocation = 'Warehouse 1 - Bay A3';
  if (!initialAsset.warrantyExpiry) initialAsset.warrantyExpiry = '15 Mar 2026';
  if (!initialAsset.warrantyDaysLeft) initialAsset.warrantyDaysLeft = '(in 243 days)';
  if (!initialAsset.usageType) initialAsset.usageType = 'Operational';
  if (!initialAsset.description) initialAsset.description = 'General purpose forklift used for warehouse operations including loading, unloading and pallet movement. Fitted with side shift and solid pneumatic tyres.';
  if (!initialAsset.notes) initialAsset.notes = 'Keep forks properly lubricated. Daily pre-start inspection required.';

  // Main Live State for Asset
  const [asset, setAsset] = useState(initialAsset);

  // Form State for Editing Modal
  const [editFormData, setEditFormData] = useState(initialAsset);

  // Form states for dropdown modals
  const [transferForm, setTransferForm] = useState({
    branch: initialAsset.branch,
    currentLocation: initialAsset.currentLocation,
    assignedTo: initialAsset.assignedTo,
    notes: ''
  });

  const [maintForm, setMaintForm] = useState({
    serviceType: 'Oil & Filter Change',
    date: '24 Jun 2025',
    provider: 'Toyota Material Handling',
    instructions: 'Perform standard 500hr servicing and oil/filter replacements.'
  });

  const [deactivateReason, setDeactivateReason] = useState('Scheduled Retirement / End of Life');

  // Mock Assignment History Table Data matching Screenshot 2 & 3
  const [assignmentsList, setAssignmentsList] = useState([
    { id: 'ASG-0006', assignedTo: 'Warehouse 1', branchLocation: 'Sydney Head Office\nWarehouse 1', purpose: 'Daily Operations\nGeneral Use', assignedBy: 'Sarah Mitchell', assignedByAvatar: 'SM', fromDate: '24 May 2025\n09:15 AM', toDate: '-\nOngoing', duration: '-', status: 'Current' },
    { id: 'ASG-0005', assignedTo: 'Dispatch Team', branchLocation: 'Sydney Head Office\nDispatch Yard', purpose: 'Loading / Dispatch\nSupport', assignedBy: 'Sarah Mitchell', assignedByAvatar: 'SM', fromDate: '10 May 2025\n07:30 AM', toDate: '23 May 2025\n04:45 PM', duration: '13 days\n9.2 Hrs/Day', status: 'Completed' },
    { id: 'ASG-0004', assignedTo: 'Warehouse 2', branchLocation: 'Sydney Head Office\nWarehouse 2', purpose: 'Stock Movement\nInternal Transfer', assignedBy: 'James Patel', assignedByAvatar: 'JP', fromDate: '25 Apr 2025\n08:00 AM', toDate: '09 May 2025\n05:00 PM', duration: '15 days\n8.1 Hrs/Day', status: 'Completed' },
    { id: 'ASG-0003', assignedTo: 'Maintenance Team', branchLocation: 'Sydney Head Office\nWorkshop', purpose: 'Maintenance Use\nTesting', assignedBy: 'James Patel', assignedByAvatar: 'JP', fromDate: '20 Apr 2025\n02:00 PM', toDate: '24 Apr 2025\n11:00 AM', duration: '4 days\n2.2 Hrs/Day', status: 'Completed' },
    { id: 'ASG-0002', assignedTo: 'Warehouse 1', branchLocation: 'Sydney Head Office\nWarehouse 1', purpose: 'Daily Operations\nGeneral Use', assignedBy: 'Sarah Mitchell', assignedByAvatar: 'SM', fromDate: '05 Apr 2025\n07:45 AM', toDate: '19 Apr 2025\n04:30 PM', duration: '15 days\n8.3 Hrs/Day', status: 'Completed' },
    { id: 'ASG-0001', assignedTo: 'Dispatch Team', branchLocation: 'Sydney Head Office\nDispatch Yard', purpose: 'Loading / Dispatch\nSupport', assignedBy: 'Sarah Mitchell', assignedByAvatar: 'SM', fromDate: '15 Mar 2025\n08:10 AM', toDate: '04 Apr 2025\n05:15 PM', duration: '21 days\n7.6 Hrs/Day', status: 'Completed' },
  ]);

  const filteredAssignments = assignmentsList.filter(item =>
    item.id.toLowerCase().includes(assignmentSearch.toLowerCase()) ||
    item.assignedTo.toLowerCase().includes(assignmentSearch.toLowerCase()) ||
    item.purpose.toLowerCase().includes(assignmentSearch.toLowerCase()) ||
    item.assignedBy.toLowerCase().includes(assignmentSearch.toLowerCase())
  );

  const handleOpenEditModal = () => {
    setEditFormData({ ...asset });
    setIsEditing(true);
  };

  const handleSaveEditAsset = (e) => {
    e.preventDefault();
    setAsset({ ...editFormData });
    setIsEditing(false);
    triggerToast('Asset Updated Successfully', `Asset ${asset.id} details have been saved live.`);
  };

  const handleConfirmTransfer = (e) => {
    e.preventDefault();
    setAsset(prev => ({
      ...prev,
      branch: transferForm.branch,
      currentLocation: transferForm.currentLocation,
      assignedTo: transferForm.assignedTo
    }));
    setIsAssignModalOpen(false);
    triggerToast('Asset Transferred Successfully', `Asset ${asset.id} reassigned to ${transferForm.branch}.`);
  };

  const handleConfirmMaintenance = (e) => {
    e.preventDefault();
    setAsset(prev => ({
      ...prev,
      nextService: maintForm.date
    }));
    setIsMaintenanceModalOpen(false);
    triggerToast('Maintenance Scheduled', `${maintForm.serviceType} booked for ${maintForm.date}.`);
  };

  const handlePrintAction = () => {
    setIsPrintQRModalOpen(false);
    triggerToast('Label Sent to Printer', `Asset Tag QR Code for ${asset.id} generated.`);
    setTimeout(() => window.print(), 500);
  };

  const handleConfirmDeactivate = () => {
    setAsset(prev => ({
      ...prev,
      status: 'Out of Service'
    }));
    setIsDeactivateModalOpen(false);
    triggerToast('Asset Deactivated', `Asset ${asset.id} status changed to Out of Service.`);
  };

  const handleCopyTag = () => {
    navigator.clipboard.writeText(asset.assetTag);
    setCopiedTag(true);
    setTimeout(() => setCopiedTag(false), 2000);
  };

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate('/company-admin/assets');
    }
  };

  return (
    <div className="flex-grow bg-[#F8FAFC] p-4 sm:p-6 pb-32 sm:pb-10 w-full text-left font-sans custom-scrollbar overflow-y-auto min-h-screen relative" style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>

      {/* TOAST NOTIFICATION */}
      {showToast && (
        <div className="fixed top-6 right-6 z-[999999] bg-slate-900 text-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-300 border border-slate-700">
          <CheckCircle2 size={18} className="text-emerald-400" />
          <div>
            <div className="text-xs font-black text-white">{toastMessage.title}</div>
            <div className="text-[10px] text-slate-300 font-medium">{toastMessage.desc}</div>
          </div>
          <button onClick={() => setShowToast(false)} className="ml-3 text-slate-400 hover:text-white cursor-pointer">
            <X size={14} />
          </button>
        </div>
      )}

      {/* BREADCRUMB */}
      <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 mb-4 overflow-x-auto pb-1 scrollbar-none">
        <Link to="/company-admin/command-centre" className="hover:text-purple-600 transition-colors whitespace-nowrap">Home</Link>
        <ChevronRight size={12} className="shrink-0" />
        <Link to="/company-admin/assets" onClick={handleBack} className="hover:text-purple-600 transition-colors whitespace-nowrap">Assets</Link>
        <ChevronRight size={12} className="shrink-0" />
        <button onClick={handleBack} className="hover:text-purple-600 transition-colors cursor-pointer whitespace-nowrap">Assets List</button>
        <ChevronRight size={12} className="shrink-0" />
        {activeTab === 'Assignments & History' ? (
          <>
            <button onClick={() => setActiveTab('Overview')} className="hover:text-purple-600 transition-colors cursor-pointer whitespace-nowrap">Asset Details</button>
            <ChevronRight size={12} className="shrink-0" />
            <span className="text-slate-800 font-bold whitespace-nowrap">Assignments & History</span>
          </>
        ) : activeTab === 'Costs & Depreciation' ? (
          <>
            <button onClick={() => setActiveTab('Overview')} className="hover:text-purple-600 transition-colors cursor-pointer whitespace-nowrap">Asset Details</button>
            <ChevronRight size={12} className="shrink-0" />
            <span className="text-slate-800 font-bold whitespace-nowrap">Costs & Depreciation</span>
          </>
        ) : (
          <span className="text-slate-800 font-bold whitespace-nowrap">Asset Details</span>
        )}
      </div>

      {/* PAGE HEADER ROW (DYNAMIC BASED ON TAB) */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-lg sm:text-xl md:text-2xl font-black text-slate-900 tracking-tight flex flex-wrap items-center gap-2">
            {activeTab === 'Assignments & History' ? (
              <>Asset Assignments & History – Forklift {asset.id}</>
            ) : activeTab === 'Costs & Depreciation' ? (
              <>Asset Costs & Depreciation – Forklift {asset.id}</>
            ) : (
              <>Asset Details – Forklift {asset.id}</>
            )}
            <span className="w-5 h-5 rounded-full bg-purple-600 text-white flex items-center justify-center text-[10px] font-black shrink-0">
              <CheckCircle2 size={12} />
            </span>
          </h1>
          <p className="text-slate-500 text-xs font-semibold mt-1">
            {activeTab === 'Assignments & History'
              ? 'Track current assignment, past usage history and transfer records for this asset.'
              : activeTab === 'Costs & Depreciation'
              ? 'Track all costs, expenses and depreciation values for this asset.'
              : 'View, manage and track all details and activities for this asset.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 sm:gap-3 w-full sm:w-auto">
          {activeTab === 'Assignments & History' ? (
            <>
              <button
                onClick={() => setActiveTab('Overview')}
                className="flex-1 sm:flex-none bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-[11px] font-bold py-2 px-3 sm:px-4 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm cursor-pointer whitespace-nowrap"
              >
                <ArrowLeft size={14} strokeWidth={2.5} /> Back to Asset Details
              </button>

              <button
                onClick={() => setIsAssignModalOpen(true)}
                className="flex-1 sm:flex-none bg-white border border-purple-200 text-purple-700 hover:bg-purple-50 text-[11px] font-bold py-2 px-3 sm:px-4 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm cursor-pointer whitespace-nowrap"
              >
                <User size={14} strokeWidth={2.5} className="text-purple-700" /> Assign / Transfer Asset
              </button>
            </>
          ) : (
            <>
              <button
                onClick={handleBack}
                className="flex-1 sm:flex-none bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-[11px] font-bold py-2 px-3 sm:px-4 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm cursor-pointer whitespace-nowrap"
              >
                <ArrowLeft size={14} strokeWidth={2.5} /> Back to Assets List
              </button>

              <button
                onClick={handleOpenEditModal}
                className="flex-1 sm:flex-none bg-white border border-purple-200 text-purple-700 hover:bg-purple-50 text-[11px] font-bold py-2 px-3 sm:px-4 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm cursor-pointer whitespace-nowrap"
              >
                <Edit size={14} strokeWidth={2.5} className="text-purple-700" /> Edit Asset
              </button>
            </>
          )}

          <div className="relative flex-1 sm:flex-none">
            <button
              onClick={() => setIsMoreActionsOpen(!isMoreActionsOpen)}
              className="w-full sm:w-auto justify-center bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-[11px] font-bold py-2 px-4 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer whitespace-nowrap"
            >
              More Actions <ChevronDown size={14} />
            </button>

            {isMoreActionsOpen && (
              <div className="absolute right-0 mt-2 w-52 bg-white border border-slate-200 rounded-xl shadow-xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <button
                  onClick={() => { setIsAssignModalOpen(true); setIsMoreActionsOpen(false); }}
                  className="w-full text-left px-3 py-2 text-xs font-bold text-slate-700 hover:bg-purple-50 hover:text-purple-700 rounded-lg flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <User size={14} className="text-purple-600" /> Assign / Transfer Asset
                </button>
                <button
                  onClick={() => { setIsMaintenanceModalOpen(true); setIsMoreActionsOpen(false); }}
                  className="w-full text-left px-3 py-2 text-xs font-bold text-slate-700 hover:bg-purple-50 hover:text-purple-700 rounded-lg flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <Wrench size={14} className="text-amber-600" /> Schedule Maintenance
                </button>
                <button
                  onClick={() => { setIsPrintQRModalOpen(true); setIsMoreActionsOpen(false); }}
                  className="w-full text-left px-3 py-2 text-xs font-bold text-slate-700 hover:bg-purple-50 hover:text-purple-700 rounded-lg flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <QrCode size={14} className="text-purple-600" /> Print Label / QR
                </button>
                <div className="border-t border-slate-100 my-1"></div>
                <button
                  onClick={() => { setIsDeactivateModalOpen(true); setIsMoreActionsOpen(false); }}
                  className="w-full text-left px-3 py-2 text-xs font-bold text-rose-600 hover:bg-rose-50 rounded-lg flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <AlertTriangle size={14} className="text-rose-500" /> Deactivate Asset
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* TOP SECTION: HERO CARD + TOP RIGHT CARD (EXACT DYNAMIC RENDERING) */}
      <div className="flex flex-col xl:flex-row gap-6 items-stretch mb-6">

        {/* TOP HERO CARD (Left) */}
        <div className="flex-1 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col md:flex-row gap-6 items-start">
          {/* Left Side: Asset Image */}
          <div className="w-full md:w-[220px] shrink-0">
            <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-100 h-44 md:h-48">
              <img
                src={asset.image}
                alt={asset.name}
                className="w-full h-full object-cover"
              />
              <span className="absolute top-2 left-2 bg-emerald-50 text-emerald-600 border border-emerald-200 px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider shadow-sm">
                {asset.status}
              </span>
            </div>
          </div>

          {/* Right Side: Data Grid */}
          <div className="flex-1 w-full">
            <div className="flex items-center gap-3 mb-3">
              <h2 className="text-xl font-black text-slate-900 tracking-tight">{asset.id}</h2>
              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded text-[9px] font-black uppercase tracking-wider">
                {asset.status}
              </span>
            </div>

            {activeTab === 'Assignments & History' ? (
              /* Screenshot 2 & 3 Hero Card Grid format */
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-y-3 gap-x-4 text-xs">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Asset Name</span>
                  <span className="text-xs font-bold text-slate-900 block">{asset.name}</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Branch / Location</span>
                  <span className="text-xs font-bold text-slate-900 block">{typeof asset.branch === 'object' ? (asset.branch?.name || asset.branch?.location || 'Sydney Head Office') : (asset.branch || 'Sydney Head Office')}</span>
                  <span className="text-[10px] text-slate-500 font-semibold block">{typeof asset.location === 'object' ? (asset.location?.name || asset.location?.location || 'Yard') : (asset.location || 'Yard')}</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Serial / Number</span>
                  <span className="text-xs font-semibold text-slate-700 block">{asset.serialNo}</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Status</span>
                  <span className="text-xs font-bold text-emerald-600 block">{asset.status}</span>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Category</span>
                  <span className="inline-block px-2 py-0.5 bg-purple-50 text-purple-700 rounded text-[10px] font-bold">
                    {asset.categoryBadge || 'Material Handling'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Current Location</span>
                  <span className="text-xs font-bold text-slate-800 block">{asset.currentLocation}</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Year of Manufacture</span>
                  <span className="text-xs font-semibold text-slate-700 block">{asset.year}</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Condition</span>
                  <span className="text-xs font-bold text-emerald-600 block">{asset.condition}</span>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Type</span>
                  <span className="text-xs font-bold text-slate-800 block">{asset.type}</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Assigned To</span>
                  <span className="text-xs font-bold text-slate-800 block">{asset.assignedTo}</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Asset Tag / QR</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-800">{asset.assetTag}</span>
                    <button onClick={handleCopyTag} className="text-slate-400 hover:text-purple-600 transition-colors cursor-pointer">
                      {copiedTag ? <Check size={12} className="text-emerald-500" /> : <Copy size={12} />}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* Screenshot 1 Hero Card Grid format */
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-y-3 gap-x-4 text-xs">
                {/* Column 1 */}
                <div className="space-y-3">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Asset Name</span>
                    <span className="text-xs font-bold text-slate-900">{asset.fullName}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Category</span>
                    <span className="text-xs font-bold text-purple-600">{asset.category}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Type</span>
                    <span className="text-xs font-bold text-slate-800">{asset.type}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Make / Model</span>
                    <span className="text-xs font-bold text-slate-800">{asset.makeModel}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Year of Manufacture</span>
                    <span className="text-xs font-semibold text-slate-700">{asset.year}</span>
                  </div>
                </div>

                {/* Column 2 */}
                <div className="space-y-3">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Serial / Number</span>
                    <span className="text-xs font-semibold text-slate-700">{asset.serialNumberFull}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Asset Tag / QR</span>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-800">{asset.assetTag}</span>
                      <button onClick={handleCopyTag} className="text-slate-400 hover:text-purple-600 transition-colors cursor-pointer">
                        {copiedTag ? <Check size={12} className="text-emerald-500" /> : <Copy size={12} />}
                      </button>
                    </div>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Branch / Location</span>
                    <span className="text-xs font-bold text-slate-800">{typeof asset.branch === 'object' ? (asset.branch?.name || asset.branch?.location || 'Sydney Head Office') : (asset.branch || 'Sydney Head Office')}</span>
                    <span className="text-[10px] text-slate-500 font-semibold block">{typeof asset.location === 'object' ? (asset.location?.name || asset.location?.location || 'Yard') : (asset.location || 'Yard')}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Current Location</span>
                    <span className="text-xs font-bold text-slate-800">{typeof asset.currentLocation === 'object' ? (asset.currentLocation?.name || asset.currentLocation?.location || 'Warehouse 1') : (asset.currentLocation || 'Warehouse 1')}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Assigned To</span>
                    <span className="text-xs font-bold text-slate-800">{typeof asset.assignedTo === 'object' ? (asset.assignedTo?.name || 'Warehouse 1') : (asset.assignedTo || 'Warehouse 1')}</span>
                  </div>
                </div>

                {/* Column 3 */}
                <div className="space-y-3">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Purchase Date</span>
                    <span className="text-xs font-bold text-slate-800">{asset.purchaseDate}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Purchase Price</span>
                    <span className="text-xs font-bold text-slate-800">{asset.purchasePrice}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Current Value (Book)</span>
                    <span className="text-xs font-bold text-slate-800">{asset.bookValue}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Supplier</span>
                    <span className="text-xs font-semibold text-slate-700">{asset.supplier}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Warranty Expiry</span>
                    <span className="text-xs font-semibold text-slate-700">{asset.warrantyExpiry}</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab !== 'Assignments & History' && (
              <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-4 text-xs font-bold">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status:</span>
                <span className="text-emerald-600">{asset.status}</span>
                <span className="text-slate-300">•</span>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Condition:</span>
                <span className="text-emerald-600">{asset.condition}</span>
              </div>
            )}
          </div>
        </div>

        {/* TOP RIGHT SIDEBAR CARD (DYNAMIC: ASSIGNMENT OVERVIEW FOR ASSIGNMENTS TAB, ASSET STATUS FOR OTHER TABS) */}
        {activeTab === 'Assignments & History' ? (
          /* ASSIGNMENT OVERVIEW CARD AT TOP RIGHT (SCREENSHOT 2 & 3) */
          <div className="w-full xl:w-[250px] shrink-0 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                ASSIGNMENT OVERVIEW
              </h3>
              <button onClick={() => alert('View Report')} className="text-[9px] font-bold text-purple-600 uppercase tracking-widest hover:underline cursor-pointer">
                View Report &rarr;
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5 flex-1">
              <div className="border border-slate-100 rounded-xl p-2.5 bg-blue-50/40 flex flex-col items-center justify-center text-center">
                <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mb-1">
                  <CheckCircle size={12} />
                </div>
                <span className="text-xs font-black text-slate-900">6</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Total Assignments</span>
              </div>

              <div className="border border-slate-100 rounded-xl p-2.5 bg-emerald-50/40 flex flex-col items-center justify-center text-center">
                <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-1">
                  <CheckCircle2 size={12} />
                </div>
                <span className="text-xs font-black text-emerald-600">1</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Current</span>
              </div>

              <div className="border border-slate-100 rounded-xl p-2.5 bg-emerald-50/40 flex flex-col items-center justify-center text-center">
                <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-1">
                  <CheckCircle size={12} />
                </div>
                <span className="text-xs font-black text-slate-900">5</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Completed</span>
              </div>

              <div className="border border-slate-100 rounded-xl p-2.5 bg-slate-50 flex flex-col items-center justify-center text-center">
                <div className="w-6 h-6 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center mb-1">
                  <X size={12} />
                </div>
                <span className="text-xs font-black text-slate-900">0</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Cancelled</span>
              </div>

              <div className="border border-slate-100 rounded-xl p-2.5 bg-teal-50/40 flex flex-col items-center justify-center text-center">
                <div className="w-6 h-6 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center mb-1">
                  <Activity size={12} />
                </div>
                <span className="text-xs font-black text-slate-900">176.5 Hrs</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Total Usage</span>
              </div>

              <div className="border border-slate-100 rounded-xl p-2.5 bg-purple-50/40 flex flex-col items-center justify-center text-center">
                <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mb-1">
                  <User size={12} />
                </div>
                <span className="text-xs font-black text-slate-900">29.4 Hrs</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Avg per Assignment</span>
              </div>

              <div className="border border-slate-100 rounded-xl p-2.5 bg-pink-50/40 flex flex-col items-center justify-center text-center">
                <div className="w-6 h-6 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center mb-1">
                  <Calendar size={12} />
                </div>
                <span className="text-xs font-black text-slate-900">21 days</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Longest Assignment</span>
              </div>

              <div className="border border-slate-100 rounded-xl p-2.5 bg-amber-50/40 flex flex-col items-center justify-center text-center">
                <div className="w-6 h-6 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mb-1">
                  <Clock size={12} />
                </div>
                <span className="text-xs font-black text-slate-900">8.1 Hrs/Day</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Avg Daily Usage</span>
              </div>
            </div>
          </div>
        ) : (
          /* ASSET STATUS CARD AT TOP RIGHT (SCREENSHOT 1) */
          <div className="w-full xl:w-[250px] shrink-0 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col justify-between">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-4">
              ASSET STATUS
            </h3>

            <div className="grid grid-cols-2 gap-3 flex-1">
              <div className="border border-slate-100 rounded-xl p-3 bg-emerald-50/40 flex flex-col items-center justify-center text-center">
                <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-1.5">
                  <CheckCircle size={16} />
                </div>
                <span className="text-xs font-black text-emerald-600">{asset.status}</span>
                <span className="text-[9px] font-semibold text-slate-400 mt-0.5">In Use</span>
              </div>

              <div className="border border-slate-100 rounded-xl p-3 bg-amber-50/40 flex flex-col items-center justify-center text-center">
                <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mb-1.5">
                  <Wrench size={16} />
                </div>
                <span className="text-xs font-black text-amber-600">{asset.condition}</span>
                <span className="text-[9px] font-semibold text-slate-400 mt-0.5">Condition</span>
              </div>

              <div className="border border-slate-100 rounded-xl p-3 bg-blue-50/40 flex flex-col items-center justify-center text-center">
                <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mb-1.5">
                  <Clock size={16} />
                </div>
                <span className="text-xs font-black text-slate-900">{asset.operatingHours}</span>
                <span className="text-[9px] font-semibold text-slate-400 mt-0.5">Operating Hours</span>
              </div>

              <div className="border border-slate-100 rounded-xl p-3 bg-slate-50 border-slate-100 flex flex-col items-center justify-center text-center">
                <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center mb-1.5">
                  <DollarSign size={16} />
                </div>
                <span className="text-xs font-black text-slate-900">$26,950.00</span>
                <span className="text-[9px] font-semibold text-slate-400 mt-0.5">Book Value</span>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* HORIZONTAL NAVIGATION TABS (MIDDLE SECTION) */}
      <div className="flex items-center gap-8 border-b border-slate-200 mb-6 overflow-x-auto pb-0">
        {[
          'Overview',
          'Specifications',
          'Assignments & History',
          'Maintenance & Service',
          'Compliance & Documents',
          'Costs & Depreciation',
          'Activity Log'
        ].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`pb-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap cursor-pointer ${activeTab === tab
                ? 'text-purple-700 border-purple-700'
                : 'text-slate-500 border-transparent hover:text-slate-800'
              }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* MAIN SECTION BELOW TABS: TAB 1 - OVERVIEW */}
      {activeTab === 'Overview' && (
        <div className="space-y-6">
          <div className="flex flex-col xl:flex-row gap-6">

            {/* LEFT MAIN COLUMN */}
          <div className="flex-1 space-y-6">

            {/* 1. ASSET OVERVIEW CARD */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                  ASSET OVERVIEW
                </h3>
                <button onClick={handleOpenEditModal} className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-600 hover:bg-purple-50 hover:text-purple-700 flex items-center gap-1 cursor-pointer transition-colors">
                  <Edit size={12} /> Edit Details
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-5 gap-x-6">

                {/* Column 1 */}
                <div className="flex items-start gap-3">
                  <FileText size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Asset ID</span>
                    <span className="text-xs font-bold text-slate-900">{asset.id}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Package size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Asset Name</span>
                    <span className="text-xs font-bold text-slate-900">{asset.fullName}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Tag size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Category</span>
                    <span className="text-xs font-bold text-slate-900">{asset.category}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Layers size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Type</span>
                    <span className="text-xs font-bold text-slate-900">{asset.type}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Wrench size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Make / Model</span>
                    <span className="text-xs font-bold text-slate-900">{asset.makeModel}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <QrCode size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Serial Number</span>
                    <span className="text-xs font-bold text-slate-900">{asset.serialNo}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Calendar size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Year of Manufacture</span>
                    <span className="text-xs font-bold text-slate-900">{asset.year}</span>
                  </div>
                </div>

                {/* Column 2 */}
                <div className="flex items-start gap-3">
                  <Calendar size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Purchase Date</span>
                    <span className="text-xs font-bold text-slate-900">{asset.purchaseDate}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <DollarSign size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Purchase Price</span>
                    <span className="text-xs font-bold text-slate-900">{asset.purchasePrice}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <DollarSign size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Current Value (Book)</span>
                    <span className="text-xs font-bold text-slate-900">{asset.bookValue}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Building size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Supplier</span>
                    <span className="text-xs font-bold text-slate-900">{asset.supplier}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Shield size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Warranty Expiry</span>
                    <span className="text-xs font-bold text-slate-900">{asset.warrantyExpiry}</span>
                    <span className="text-[10px] text-amber-600 font-bold block">{asset.warrantyDaysLeft}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle2 size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Status</span>
                    <span className="inline-block px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded text-[10px] font-black uppercase tracking-wider">
                      {asset.status}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Condition</span>
                    <span className="text-xs font-bold text-emerald-600">{asset.condition}</span>
                  </div>
                </div>

                {/* Column 3 */}
                <div className="flex items-start gap-3">
                  <Building size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Branch / Location</span>
                    <span className="text-xs font-bold text-slate-900">{asset.branch}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <ArrowRight size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Current Location</span>
                    <span className="text-xs font-bold text-slate-900">{asset.currentLocation}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <User size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Assigned To</span>
                    <span className="text-xs font-bold text-slate-900">{asset.assignedTo}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Activity size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Usage Type</span>
                    <span className="text-xs font-bold text-slate-900">{asset.usageType}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Operating Hours</span>
                    <span className="text-xs font-bold text-slate-900">{asset.operatingHours}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <BarChart2 size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Last Odometer / Meter</span>
                    <span className="text-xs font-bold text-slate-900">{asset.odometer}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Calendar size={16} className="text-slate-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Next Service Due</span>
                    <span className="text-xs font-bold text-slate-900">{asset.nextService}</span>
                    <span className="text-[10px] text-amber-600 font-bold block">{asset.nextServiceDays}</span>
                  </div>
                </div>

              </div>
            </div>

            {/* 2. ASSET DESCRIPTION & NOTES CARD */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                  ASSET DESCRIPTION & NOTES
                </h3>
                <button onClick={handleOpenEditModal} className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-600 hover:bg-purple-50 hover:text-purple-700 flex items-center gap-1 cursor-pointer transition-colors">
                  <Edit size={12} /> Edit
                </button>
              </div>

              <p className="text-xs text-slate-600 font-medium leading-relaxed mb-3">
                {asset.description}
              </p>

              <div className="text-xs text-slate-700 font-semibold bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="font-bold text-slate-900">Notes: </span>
                {asset.notes}
              </div>
            </div>

            {/* 3. BOTTOM 3 CARDS ROW (LAST MAINTENANCE, COST SUMMARY, OPERATING SUMMARY) */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

              {/* LAST MAINTENANCE */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col justify-between">
                <div>
                  <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-4">
                    LAST MAINTENANCE
                  </h3>

                  <div className="flex justify-between items-start mb-2">
                    <span className="text-xs font-bold text-slate-900">Oil & Filter Change</span>
                    <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded text-[9px] font-black uppercase tracking-wider">
                      Completed
                    </span>
                  </div>

                  <div className="space-y-1 text-xs text-slate-600 font-medium mb-4">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Date</span>
                      <span className="font-bold text-slate-800">25 Apr 2025 <span className="text-slate-400 font-normal">in 18 days</span></span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">By</span>
                      <span className="font-bold text-slate-800">James Patel</span>
                    </div>
                  </div>
                </div>

                <button onClick={() => setActiveTab('Maintenance & Service')} className="text-xs font-bold text-purple-600 hover:text-purple-700 flex items-center gap-1 transition-colors self-start cursor-pointer">
                  View Maintenance History &rarr;
                </button>
              </div>

              {/* COST SUMMARY (FY 2024-2025) */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                      COST SUMMARY (FY 2024-2025)
                    </h3>
                    <button onClick={() => setActiveTab('Costs & Depreciation')} className="text-[9px] font-bold text-purple-600 uppercase tracking-widest hover:underline cursor-pointer">
                      View All &rarr;
                    </button>
                  </div>

                  <div className="space-y-2 text-xs font-medium text-slate-600">
                    <div className="flex justify-between">
                      <span>Total Maintenance Cost</span>
                      <span className="font-bold text-slate-900">$1,250.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Repair Cost</span>
                      <span className="font-bold text-slate-900">$450.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Fuel / Operating Cost</span>
                      <span className="font-bold text-slate-900">$2,150.00</span>
                    </div>
                    <div className="border-t border-slate-100 pt-2 flex justify-between font-bold text-slate-900">
                      <span>Total Cost (YTD)</span>
                      <span>$3,850.00</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* OPERATING SUMMARY */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                      OPERATING SUMMARY
                    </h3>
                    <button onClick={() => setActiveTab('Specifications')} className="text-[9px] font-bold text-purple-600 uppercase tracking-widest hover:underline cursor-pointer">
                      View All &rarr;
                    </button>
                  </div>

                  <div className="space-y-3 text-xs font-medium text-slate-600">
                    <div className="flex justify-between">
                      <span>Operating Hours (This Month)</span>
                      <span className="font-bold text-slate-900">120.5 Hrs</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Operating Hours (YTD)</span>
                      <span className="font-bold text-slate-900">1,256.5 Hrs</span>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px]">
                        <span>Utilisation (This Month)</span>
                        <span className="font-bold text-slate-900">66%</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-purple-600 rounded-full" style={{ width: '66%' }}></div>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px]">
                        <span>Utilisation (YTD)</span>
                        <span className="font-bold text-slate-900">84%</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-purple-600 rounded-full" style={{ width: '84%' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>

          </div>

          {/* RIGHT SIDEBAR COLUMN (BELOW TABS) */}
          <div className="w-full xl:w-[250px] shrink-0 space-y-6">

            {/* 1. COMPLIANCE STATUS CARD */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                  COMPLIANCE STATUS
                </h3>
                <button onClick={() => setActiveTab('Compliance & Documents')} className="text-[9px] font-bold text-purple-600 uppercase tracking-widest hover:underline cursor-pointer">
                  View All &rarr;
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">Registration / Compliance</span>
                  <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded text-[9px] font-black uppercase">Compliant</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">Insurance</span>
                  <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded text-[9px] font-black uppercase">Compliant</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">Inspection / Check</span>
                  <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[9px] font-black uppercase">Up to Date</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">Licence / Permit</span>
                  <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded text-[9px] font-black uppercase">Compliant</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">Certification</span>
                  <span className="px-2 py-0.5 bg-amber-50 text-amber-600 rounded text-[9px] font-black uppercase">Expires Soon (30 days)</span>
                </div>
              </div>
            </div>

            {/* 2. UPCOMING MAINTENANCE CARD */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                  UPCOMING MAINTENANCE
                </h3>
                <button onClick={() => setActiveTab('Maintenance & Service')} className="text-[9px] font-bold text-purple-600 uppercase tracking-widest hover:underline cursor-pointer">
                  View All &rarr;
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs p-2 bg-amber-50/50 rounded-xl border border-amber-100">
                  <div className="flex items-center gap-2">
                    <AlertTriangle size={14} className="text-amber-500" />
                    <div>
                      <div className="font-bold text-slate-900">Service Due</div>
                      <div className="text-[10px] text-slate-500 font-semibold">24 Jun 2025</div>
                    </div>
                  </div>
                  <span className="text-[9px] font-bold text-amber-600">in 18 days</span>
                </div>

                <div className="flex items-center justify-between text-xs p-2 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex items-center gap-2">
                    <Wrench size={14} className="text-slate-500" />
                    <div>
                      <div className="font-bold text-slate-900">Oil & Filter Change</div>
                      <div className="text-[10px] text-slate-500 font-semibold">24 Jun 2025</div>
                    </div>
                  </div>
                  <span className="text-[9px] font-bold text-slate-500">in 18 days</span>
                </div>

                <div className="flex items-center justify-between text-xs p-2 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex items-center gap-2">
                    <CheckCircle size={14} className="text-slate-500" />
                    <div>
                      <div className="font-bold text-slate-900">Full Inspection</div>
                      <div className="text-[10px] text-slate-500 font-semibold">24 Aug 2025</div>
                    </div>
                  </div>
                  <span className="text-[9px] font-bold text-slate-500">in 79 days</span>
                </div>
              </div>
            </div>

            {/* 3. QUICK ACTIONS CARD */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-4">
                QUICK ACTIONS
              </h3>

              <div className="space-y-1">
                {[
                  { icon: <Edit size={14} />, label: 'Edit Asset', action: handleOpenEditModal },
                  { icon: <User size={14} />, label: 'Assign / Transfer Asset', action: () => setIsAssignModalOpen(true) },
                  { icon: <Calendar size={14} />, label: 'Schedule Maintenance', action: () => setIsMaintenanceModalOpen(true) },
                  { icon: <FileText size={14} />, label: 'Add Compliance Document', action: () => setActiveTab('Compliance & Documents') },
                  { icon: <Plus size={14} />, label: 'Add Note', action: handleOpenEditModal },
                  { icon: <QrCode size={14} />, label: 'Print Asset Label / QR', action: () => setIsPrintQRModalOpen(true) }
                ].map((act, i) => (
                  <button
                    key={i}
                    onClick={act.action}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 hover:bg-slate-50 hover:text-purple-700 transition-colors text-left group cursor-pointer"
                  >
                    <span className="text-slate-400 group-hover:text-purple-600 transition-colors">{act.icon}</span>
                    <span className="text-xs font-bold">{act.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 4. RECENT ACTIVITY CARD */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                  RECENT ACTIVITY
                </h3>
                <button onClick={() => setActiveTab('Activity Log')} className="text-[9px] font-bold text-purple-600 uppercase tracking-widest hover:underline cursor-pointer">
                  View All &rarr;
                </button>
              </div>

              <div className="relative pl-4 space-y-4 before:absolute before:left-1.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-100">
                <div className="relative">
                  <div className="absolute -left-[19px] top-1 w-2.5 h-2.5 rounded-full bg-purple-600 border-2 border-white"></div>
                  <div className="text-xs font-bold text-slate-900">Asset assigned to Warehouse 1</div>
                  <div className="text-[10px] text-slate-400 font-semibold mt-0.5">By Sarah M. • 10 May 2025</div>
                </div>

                <div className="relative">
                  <div className="absolute -left-[19px] top-1 w-2.5 h-2.5 rounded-full bg-purple-600 border-2 border-white"></div>
                  <div className="text-xs font-bold text-slate-900">Maintenance completed - Oil & Filter Change</div>
                  <div className="text-[10px] text-slate-400 font-semibold mt-0.5">By James P. • 25 Apr 2025</div>
                </div>

                <div className="relative">
                  <div className="absolute -left-[19px] top-1 w-2.5 h-2.5 rounded-full bg-purple-600 border-2 border-white"></div>
                  <div className="text-xs font-bold text-slate-900">Inspection completed - Daily Check</div>
                  <div className="text-[10px] text-slate-400 font-semibold mt-0.5">By Robert T. • 10 Apr 2025</div>
                </div>

                <div className="relative">
                  <div className="absolute -left-[19px] top-1 w-2.5 h-2.5 rounded-full bg-purple-600 border-2 border-white"></div>
                  <div className="text-xs font-bold text-slate-900">Asset created</div>
                  <div className="text-[10px] text-slate-400 font-semibold mt-0.5">By Sarah M. • 15 Mar 2022</div>
                </div>
              </div>
            </div>

          </div>
          </div>


        </div>
      )}

      {/* MAIN SECTION BELOW TABS: TAB 2 - ASSIGNMENTS & HISTORY (SCREENSHOT 2 & 3 MATCH) */}
      {activeTab === 'Assignments & History' && (
        <div className="space-y-6">
          <div className="flex flex-col xl:flex-row gap-6">

            {/* LEFT MAIN COLUMN */}
          <div className="flex-1 space-y-6">

            {/* INNER SUB-TABS HEADER */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex items-center gap-6 border-b border-slate-200 pb-0 mb-5 overflow-x-auto">
                {[
                  'Current Assignment',
                  'Assignment History',
                  'Transfer History',
                  'Utilisation History',
                  'Usage Summary'
                ].map((subTab) => (
                  <button
                    key={subTab}
                    onClick={() => setActiveSubTab(subTab)}
                    className={`pb-2.5 text-xs font-bold transition-all border-b-2 whitespace-nowrap cursor-pointer ${activeSubTab === subTab
                        ? 'text-purple-700 border-purple-700'
                        : 'text-slate-500 border-transparent hover:text-slate-800'
                      }`}
                  >
                    {subTab}
                  </button>
                ))}
              </div>

              {/* CURRENT ASSIGNMENT CARD */}
              <div className="mb-6">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-4">
                  CURRENT ASSIGNMENT
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 bg-slate-50/60 p-4 rounded-xl border border-slate-100 text-xs">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Assigned To</span>
                    <span className="font-bold text-slate-900 block">{asset.assignedTo}</span>
                    <span className="text-[10px] text-slate-500 font-semibold block">[Internal Location]</span>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Branch</span>
                    <span className="font-bold text-slate-900 block">{asset.branch}</span>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Assigned By</span>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="w-4 h-4 rounded-full bg-slate-200 text-[9px] font-black text-slate-700 flex items-center justify-center">SM</span>
                      <div>
                        <span className="font-bold text-slate-900 block leading-tight">Sarah Mitchell</span>
                        <span className="text-[9px] text-slate-500 font-semibold block">Super Admin</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Assigned Date</span>
                    <span className="font-bold text-slate-900 block">24 May 2025</span>
                    <span className="text-[10px] text-slate-500 font-semibold block">09:15 AM</span>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Purpose</span>
                    <span className="font-bold text-slate-900 block">Daily Operations</span>
                    <span className="text-[10px] text-slate-500 font-semibold block">(General Use)</span>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Expected Return</span>
                    <span className="font-bold text-emerald-600 block">- Ongoing</span>
                  </div>
                </div>
              </div>

              {/* ASSIGNMENT HISTORY (6) TABLE */}
              <div>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4">
                  <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                    ASSIGNMENT HISTORY ({filteredAssignments.length})
                  </h3>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <div className="relative flex-1 sm:w-60">
                      <Search size={14} className="absolute left-3 top-2.5 text-slate-400" />
                      <input
                        type="text"
                        value={assignmentSearch}
                        onChange={(e) => setAssignmentSearch(e.target.value)}
                        placeholder="Search assignments..."
                        className="w-full bg-white border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500"
                      />
                    </div>
                    <button className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 cursor-pointer">
                      <Filter size={12} /> Filters
                    </button>
                    <button className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-1.5 cursor-pointer">
                      <Download size={12} /> Export
                    </button>
                  </div>
                </div>

                {/* TABLE */}
                <div className="overflow-x-auto border border-slate-200 rounded-xl">
                  <table className="w-full text-left text-xs border-collapse min-w-[950px]">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-black text-slate-500 uppercase tracking-wider">
                        <th className="p-3 whitespace-nowrap">Assignment ID</th>
                        <th className="p-3 whitespace-nowrap">Assigned To</th>
                        <th className="p-3 whitespace-nowrap">Branch / Location</th>
                        <th className="p-3 whitespace-nowrap">Purpose</th>
                        <th className="p-3 whitespace-nowrap">Assigned By</th>
                        <th className="p-3 whitespace-nowrap">From Date / Time</th>
                        <th className="p-3 whitespace-nowrap">To Date / Time</th>
                        <th className="p-3 whitespace-nowrap">Duration</th>
                        <th className="p-3 whitespace-nowrap">Status</th>
                        <th className="p-3 text-center whitespace-nowrap">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredAssignments.map((asg, idx) => (
                        <tr key={asg.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3 font-bold text-purple-700 whitespace-nowrap">{asg.id}</td>
                          <td className="p-3 font-bold text-slate-900 whitespace-nowrap">{asg.assignedTo}</td>
                          <td className="p-3 font-semibold text-slate-700 whitespace-nowrap leading-tight">{asg.branchLocation}</td>
                          <td className="p-3 font-semibold text-slate-700 whitespace-nowrap leading-tight">{asg.purpose}</td>
                          <td className="p-3 whitespace-nowrap">
                            <div className="flex items-center gap-1.5">
                              <span className="w-5 h-5 rounded-full bg-slate-200 text-[9px] font-black text-slate-700 flex items-center justify-center shrink-0">{asg.assignedByAvatar}</span>
                              <span className="font-bold text-slate-900 whitespace-nowrap">{asg.assignedBy}</span>
                            </div>
                          </td>
                          <td className="p-3 font-medium text-slate-700 whitespace-nowrap leading-tight">{asg.fromDate}</td>
                          <td className="p-3 font-medium text-slate-700 whitespace-nowrap leading-tight">{asg.toDate}</td>
                          <td className="p-3 font-medium text-slate-700 whitespace-nowrap leading-tight">{asg.duration}</td>
                          <td className="p-3 whitespace-nowrap">
                            {asg.status === 'Current' ? (
                              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded text-[9px] font-black uppercase tracking-wider">Current</span>
                            ) : (
                              <span className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded text-[9px] font-black uppercase tracking-wider">Completed</span>
                            )}
                          </td>
                          <td className="p-3 whitespace-nowrap relative">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                title="View Assignment Details"
                                onClick={() => setViewAssignmentModal(asg)}
                                className="w-7 h-7 rounded-md bg-slate-100 text-slate-600 hover:bg-purple-100 hover:text-purple-700 flex items-center justify-center transition-colors cursor-pointer"
                              >
                                <Eye size={14} />
                              </button>

                              <div className="relative">
                                <button
                                  title="More Actions"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setAsgMenuIndex(asgMenuIndex === idx ? null : idx);
                                  }}
                                  className={`w-7 h-7 rounded-md ${asgMenuIndex === idx ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600 hover:bg-purple-100 hover:text-purple-700'} flex items-center justify-center transition-colors cursor-pointer`}
                                >
                                  <MoreHorizontal size={14} />
                                </button>

                                {asgMenuIndex === idx && (
                                  <>
                                    <div className="fixed inset-0 z-40" onClick={() => setAsgMenuIndex(null)} />
                                    <div className="absolute right-0 top-full mt-1 w-44 bg-white rounded-xl shadow-xl border border-slate-200 p-1.5 z-50 flex flex-col gap-0.5 text-xs font-semibold text-slate-700">
                                      <button
                                        onClick={() => { setViewAssignmentModal(asg); setAsgMenuIndex(null); }}
                                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                      >
                                        👁️ View Details
                                      </button>
                                      <button
                                        onClick={() => { setEditAssignmentModal({ ...asg, index: idx }); setAsgMenuIndex(null); }}
                                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                      >
                                        ✏️ Edit Assignment
                                      </button>
                                      <button
                                        onClick={() => { triggerToast('Assignment Exported', `Exported details for ${asg.id}`); setAsgMenuIndex(null); }}
                                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                      >
                                        📄 Export Details
                                      </button>
                                      <div className="h-px bg-slate-100 my-1" />
                                      <button
                                        disabled={asg.status === 'Completed'}
                                        onClick={() => {
                                          if (asg.status === 'Completed') return;
                                          setAssignmentsList(prev => prev.map((item, i) => i === idx ? { ...item, status: 'Completed', toDate: '24 May 2025\n12:00 PM' } : item));
                                          triggerToast('Assignment Ended', `Assignment ${asg.id} completed.`);
                                          setAsgMenuIndex(null);
                                        }}
                                        className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left w-full cursor-pointer ${asg.status === 'Completed' ? 'text-slate-400 opacity-60 cursor-not-allowed' : 'text-rose-600 hover:bg-rose-50'}`}
                                      >
                                        ⏹️ End Assignment
                                      </button>
                                    </div>
                                  </>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* TABLE PAGINATION */}
                <div className="flex justify-between items-center text-xs text-slate-500 font-semibold mt-4">
                  <span>Showing 1 to {filteredAssignments.length} of {filteredAssignments.length} assignments</span>
                  <div className="flex items-center gap-2">
                    <button className="px-2.5 py-1 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-600 disabled:opacity-50" disabled>&lt;</button>
                    <span className="px-3 py-1 bg-purple-50 border border-purple-200 rounded-lg font-bold text-purple-700">1</span>
                    <button className="px-2.5 py-1 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-600 disabled:opacity-50" disabled>&gt;</button>
                    <select className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs font-semibold text-slate-700 outline-none">
                      <option>10 / page</option>
                      <option>25 / page</option>
                      <option>50 / page</option>
                    </select>
                  </div>
                </div>

              </div>
            </div>

          </div>

          {/* RIGHT SIDEBAR COLUMN FOR ASSIGNMENTS & HISTORY (UPCOMING ASSIGNMENTS & QUICK ACTIONS) */}
          <div className="w-full xl:w-[250px] shrink-0 space-y-6">

            {/* 1. UPCOMING ASSIGNMENTS CARD */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">
                  UPCOMING ASSIGNMENTS
                </h3>
                <button onClick={() => alert('View All Assignments')} className="text-[9px] font-bold text-purple-600 uppercase tracking-widest hover:underline cursor-pointer">
                  View All &rarr;
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs p-2.5 bg-amber-50/50 rounded-xl border border-amber-100">
                  <div className="flex items-center gap-2">
                    <Calendar size={14} className="text-amber-500 shrink-0" />
                    <div>
                      <div className="font-bold text-slate-900">Service & Maintenance</div>
                      <div className="text-[10px] text-slate-500 font-semibold">Scheduled Use</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-bold text-slate-900">24 Jun 2025</div>
                    <div className="text-[9px] font-bold text-amber-600">in 18 days</div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs p-2.5 bg-purple-50/50 rounded-xl border border-purple-100">
                  <div className="flex items-center gap-2">
                    <Package size={14} className="text-purple-600 shrink-0" />
                    <div>
                      <div className="font-bold text-slate-900">Warehouse 1</div>
                      <div className="text-[10px] text-slate-500 font-semibold">Daily Operations</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-bold text-slate-900">24 Jun 2025</div>
                    <div className="text-[9px] font-bold text-amber-600">in 18 days</div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs p-2.5 bg-blue-50/50 rounded-xl border border-blue-100">
                  <div className="flex items-center gap-2">
                    <Users size={14} className="text-blue-600 shrink-0" />
                    <div>
                      <div className="font-bold text-slate-900">Dispatch Team</div>
                      <div className="text-[10px] text-slate-500 font-semibold">Loading / Dispatch</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-bold text-slate-900">25 Jun 2025</div>
                    <div className="text-[9px] font-bold text-amber-600">in 19 days</div>
                  </div>
                </div>
              </div>
            </div>

            {/* 2. QUICK ACTIONS CARD */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-4">
                QUICK ACTIONS
              </h3>

              <div className="space-y-1">
                {[
                  { icon: <User size={14} />, label: 'Assign / Transfer Asset', action: () => setIsAssignModalOpen(true) },
                  { icon: <RotateCcw size={14} />, label: 'Return Asset', action: () => triggerToast('Asset Returned', 'Asset returned to main repository.') },
                  { icon: <Calendar size={14} />, label: 'View Assignment Calendar', action: () => alert('Opening Assignment Calendar...') },
                  { icon: <TrendingUp size={14} />, label: 'View Utilisation Report', action: () => alert('Opening Utilisation Report...') },
                  { icon: <FileText size={14} />, label: 'Print Assignment History', action: handlePrintAction },
                  { icon: <Download size={14} />, label: 'Export Assignment Data', action: () => triggerToast('Export Complete', 'Assignment history exported as CSV.') }
                ].map((act, i) => (
                  <button
                    key={i}
                    onClick={act.action}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 hover:bg-slate-50 hover:text-purple-700 transition-colors text-left group cursor-pointer"
                  >
                    <span className="text-slate-400 group-hover:text-purple-600 transition-colors">{act.icon}</span>
                    <span className="text-xs font-bold">{act.label}</span>
                  </button>
                ))}
              </div>
            </div>

          </div>
          </div>

          {/* DEVELOPER NOTES - ASSET ASSIGNMENTS & HISTORY CARD */}
          <div className="bg-purple-50/50 rounded-2xl border border-purple-100 p-4 sm:p-6 shadow-sm">
            <h4 className="text-xs font-black text-purple-900 flex items-center gap-2 mb-4 uppercase tracking-widest">
              <Info size={14} className="text-purple-600 shrink-0" /> DEVELOPER NOTES - ASSET ASSIGNMENTS & HISTORY
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6">
              <div className="bg-white/60 sm:bg-transparent p-3.5 sm:p-0 rounded-xl border border-purple-100/60 sm:border-0">
                <div className="flex items-center gap-1.5 mb-2 text-[10px] font-black text-purple-800 uppercase tracking-widest">
                  1. PURPOSE
                </div>
                <ul className="text-[10px] font-medium text-slate-600 space-y-1.5 list-disc pl-3">
                  <li>Track current and past assignments.</li>
                  <li>Monitor usage, transfer and return history.</li>
                  <li>Ensure full asset accountability.</li>
                </ul>
              </div>
              <div className="bg-white/60 sm:bg-transparent p-3.5 sm:p-0 rounded-xl border border-purple-100/60 sm:border-0">
                <div className="flex items-center gap-1.5 mb-2 text-[10px] font-black text-purple-800 uppercase tracking-widest">
                  2. KEY FEATURES
                </div>
                <ul className="text-[10px] font-medium text-slate-600 space-y-1.5 list-disc pl-3">
                  <li>Current assignment with expected return.</li>
                  <li>Complete assignment and transfer history.</li>
                  <li>Utilisation and usage summary.</li>
                  <li>Upcoming assignments and calendar view.</li>
                </ul>
              </div>
              <div className="bg-white/60 sm:bg-transparent p-3.5 sm:p-0 rounded-xl border border-purple-100/60 sm:border-0">
                <div className="flex items-center gap-1.5 mb-2 text-[10px] font-black text-purple-800 uppercase tracking-widest">
                  3. AUTOMATION & ALERTS
                </div>
                <ul className="text-[10px] font-medium text-slate-600 space-y-1.5 list-disc pl-3">
                  <li>Notify on overdue returns.</li>
                  <li>Reminder before scheduled assignments.</li>
                  <li>Auto-update usage hours from telematics.</li>
                  <li>AI insights for idle or underutilised assets.</li>
                </ul>
              </div>
              <div className="bg-white/60 sm:bg-transparent p-3.5 sm:p-0 rounded-xl border border-purple-100/60 sm:border-0">
                <div className="flex items-center gap-1.5 mb-2 text-[10px] font-black text-purple-800 uppercase tracking-widest">
                  4. PERMISSIONS
                </div>
                <ul className="text-[10px] font-medium text-slate-600 space-y-1.5 list-disc pl-3">
                  <li>Super Admin: Full access.</li>
                  <li>Admin/Manager: Create, edit, assign.</li>
                  <li>Dispatch: Assign & view assignments.</li>
                  <li>Staff: View assigned assets only.</li>
                </ul>
              </div>
              <div className="bg-white/60 sm:bg-transparent p-3.5 sm:p-0 rounded-xl border border-purple-100/60 sm:border-0">
                <div className="flex items-center gap-1.5 mb-2 text-[10px] font-black text-purple-800 uppercase tracking-widest">
                  5. DATA SOURCES
                </div>
                <ul className="text-[10px] font-medium text-slate-600 space-y-1.5 list-disc pl-3">
                  <li>Assets module.</li>
                  <li>Assignments & Transfers.</li>
                  <li>Live Tracking / Telematics.</li>
                  <li>Maintenance module.</li>
                </ul>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-purple-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-[9px] font-semibold text-slate-500">
              <span>All times shown in your local time (AEST)</span>
              <span className="flex items-center gap-1"><RefreshCw size={10} /> Data auto-refreshes every 5 minutes</span>
            </div>
          </div>
        </div>
      )}

      {/* MAIN SECTION BELOW TABS: SPECIFICATIONS TAB */}
      
      
      {activeTab === 'Maintenance & Service' && (
        <div className="space-y-6">
          {/* Inner Navigation Tabs */}
          <div className="flex items-center gap-6 border-b border-slate-200 overflow-x-auto custom-scrollbar">
            {['Maintenance Schedule', 'Service History', 'Inspection History', 'Parts & Labour', 'Cost Summary', 'Downtime Log'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveMaintTab(tab)}
                className={`pb-3 text-xs font-bold transition-all border-b-2 cursor-pointer whitespace-nowrap ${activeMaintTab === tab ? 'text-purple-700 border-purple-700' : 'text-slate-500 border-transparent hover:text-slate-800'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
            
            {/* LEFT COLUMN: TABLE */}
            <div className="flex flex-col space-y-4">
              
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">MAINTENANCE SCHEDULE ({mockMaintenanceTasks.length})</h3>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full">
                {/* Table Header Controls */}
                <div className="p-3.5 border-b border-slate-100 flex items-center justify-between gap-2.5 overflow-x-auto custom-scrollbar">
                  <div className="flex items-center gap-2 flex-nowrap shrink-0">
                    <div className="relative">
                      <Search size={14} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
                      <input type="text" placeholder="Search maintenance..." className="pl-9 pr-3 py-1.5 border border-slate-200 rounded-lg text-[11px] font-semibold text-slate-700 outline-none focus:border-purple-500 w-44" />
                    </div>
                    
                    <button className="flex items-center gap-1.5 px-2.5 py-1.5 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition-colors bg-white whitespace-nowrap cursor-pointer">
                      All Maintenance Types <ChevronDown size={12} className="text-slate-400" />
                    </button>
                    <button className="flex items-center gap-1.5 px-2.5 py-1.5 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition-colors bg-white whitespace-nowrap cursor-pointer">
                      All Status <ChevronDown size={12} className="text-slate-400" />
                    </button>
                    <button className="flex items-center gap-1.5 px-2.5 py-1.5 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition-colors bg-white whitespace-nowrap cursor-pointer">
                      All Priority <ChevronDown size={12} className="text-slate-400" />
                    </button>
                    
                    <button className="flex items-center gap-1.5 px-2.5 py-1.5 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition-colors bg-white whitespace-nowrap cursor-pointer">
                      <Filter size={12} /> Filters
                    </button>
                  </div>
                  
                  <button className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition-colors bg-white whitespace-nowrap cursor-pointer shrink-0">
                    <Download size={12} /> Export
                  </button>
                </div>

                {/* Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse min-w-[1000px]">
                    <thead>
                      <tr className="border-b border-slate-100 bg-slate-50/50">
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Task / Maintenance</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Type</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Priority</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Frequency / Interval</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Last Performed</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Next Due</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Status</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Days Remaining</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Assigned To</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider text-center whitespace-nowrap">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {maintTasksList.map((task, idx) => (
                        <tr key={idx} className="border-b border-slate-50 hover:bg-slate-50/80 transition-colors">
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <h4 className="text-[11px] font-bold text-slate-800">{task.task}</h4>
                            <p className="text-[10px] font-medium text-slate-500 mt-0.5">{task.desc}</p>
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <span className={`text-[11px] font-bold ${task.type === 'Service' ? 'text-purple-600' : 'text-amber-500'}`}>
                              {task.type}
                            </span>
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <span className={`text-[11px] font-bold ${task.priority === 'High' ? 'text-rose-500' : task.priority === 'Medium' ? 'text-amber-500' : 'text-emerald-500'}`}>
                              {task.priority}
                            </span>
                          </td>
                          <td className="px-5 py-3.5 text-[11px] font-semibold text-slate-700 whitespace-nowrap">{task.freq}</td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <span className="text-[11px] font-semibold text-slate-700 block">{task.lastDate}</span>
                            {task.lastHrs && <span className="text-[10px] font-semibold text-slate-500 block">@ {task.lastHrs}</span>}
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <span className="text-[11px] font-semibold text-slate-700 block">{task.nextDate}</span>
                            {task.nextHrs && <span className="text-[10px] font-semibold text-slate-500 block">@ {task.nextHrs}</span>}
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <span className={`text-[10px] font-bold ${task.status === 'Due Soon' ? 'text-amber-500' : task.status === 'Scheduled' ? 'text-blue-500' : 'text-emerald-500'}`}>
                              {task.status}
                            </span>
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <span className={`text-[10px] font-bold ${task.daysRemaining === 'Completed' ? 'text-emerald-500' : task.daysRemaining.includes('18') ? 'text-amber-500' : 'text-blue-500'}`}>
                              {task.daysRemaining}
                            </span>
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <h4 className="text-[11px] font-bold text-slate-800">{task.assigned}</h4>
                            {task.role && <p className="text-[10px] font-medium text-slate-500 mt-0.5">{task.role}</p>}
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap relative">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                title="View Maintenance Task Details"
                                onClick={() => setViewMaintTaskModal(task)}
                                className="w-7 h-7 rounded-md bg-slate-100 text-slate-600 hover:bg-purple-100 hover:text-purple-700 flex items-center justify-center transition-colors cursor-pointer"
                              >
                                <Eye size={14} />
                              </button>

                              <div className="relative">
                                <button
                                  title="More Actions"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setMaintMenuIndex(maintMenuIndex === idx ? null : idx);
                                  }}
                                  className={`w-7 h-7 rounded-md ${maintMenuIndex === idx ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600 hover:bg-purple-100 hover:text-purple-700'} flex items-center justify-center transition-colors cursor-pointer`}
                                >
                                  <MoreHorizontal size={14} />
                                </button>

                                {maintMenuIndex === idx && (
                                  <>
                                    <div className="fixed inset-0 z-40" onClick={() => setMaintMenuIndex(null)} />
                                    <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-xl shadow-xl border border-slate-200 p-1.5 z-50 flex flex-col gap-0.5 text-xs font-semibold text-slate-700">
                                      <button
                                        onClick={() => { setViewMaintTaskModal(task); setMaintMenuIndex(null); }}
                                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                      >
                                        👁️ View Details
                                      </button>
                                      <button
                                        disabled={task.status === 'Completed'}
                                        onClick={() => {
                                          if (task.status === 'Completed') return;
                                          setMaintTasksList(prev => prev.map((item, i) => i === idx ? { ...item, status: 'Completed', daysRemaining: 'Completed' } : item));
                                          triggerToast('Maintenance Completed', `Task "${task.task}" marked as completed.`);
                                          setMaintMenuIndex(null);
                                        }}
                                        className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left w-full cursor-pointer ${task.status === 'Completed' ? 'text-slate-400 opacity-60 cursor-not-allowed' : 'text-emerald-600 hover:bg-emerald-50'}`}
                                      >
                                        ✅ Mark as Completed
                                      </button>
                                      <button
                                        onClick={() => { triggerToast('Service Rescheduled', `Reschedule requested for "${task.task}"`); setMaintMenuIndex(null); }}
                                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                      >
                                        📅 Reschedule Service
                                      </button>
                                      <div className="h-px bg-slate-100 my-1" />
                                      <button
                                        disabled={task.status === 'Completed'}
                                        onClick={() => {
                                          if (task.status === 'Completed') return;
                                          setMaintTasksList(prev => prev.filter((_, i) => i !== idx));
                                          triggerToast('Task Cancelled', `Maintenance task "${task.task}" cancelled.`);
                                          setMaintMenuIndex(null);
                                        }}
                                        className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left w-full cursor-pointer ${task.status === 'Completed' ? 'text-slate-400 opacity-60 cursor-not-allowed' : 'text-rose-600 hover:bg-rose-50'}`}
                                      >
                                        ❌ Cancel Task
                                      </button>
                                    </div>
                                  </>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                {/* Pagination Footer */}
                <div className="p-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium bg-slate-50/30">
                  <span>Showing 1 to {mockMaintenanceTasks.length} of {mockMaintenanceTasks.length} maintenance tasks</span>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <button className="w-6 h-6 flex items-center justify-center rounded text-slate-400"><ChevronLeft size={14} /></button>
                      <button className="w-6 h-6 flex items-center justify-center rounded bg-purple-700 text-white font-bold">1</button>
                      <button className="w-6 h-6 flex items-center justify-center rounded text-slate-400"><ChevronRight size={14} /></button>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-700 text-[10px]">10 / page</span>
                      <ChevronDown size={14} className="text-slate-400" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN: INSIGHTS & ALERTS */}
            <div className="space-y-6">
              
              {/* Maintenance Summary */}
              <div>
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-3">Maintenance Summary</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white border border-purple-100 rounded-xl p-3 flex flex-col shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-6 h-6 rounded-full bg-purple-50 flex items-center justify-center text-purple-600 border border-purple-100"><Calendar size={12} /></div>
                      <span className="text-lg font-black text-slate-800">7</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Total Tasks</span>
                  </div>
                  <div className="bg-white border border-amber-100 rounded-xl p-3 flex flex-col shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-6 h-6 rounded-full bg-amber-50 flex items-center justify-center text-amber-600 border border-amber-100"><Clock size={12} /></div>
                      <span className="text-lg font-black text-slate-800">2</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Due Soon</span>
                  </div>
                  <div className="bg-white border border-rose-100 rounded-xl p-3 flex flex-col shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-6 h-6 rounded-full bg-rose-50 flex items-center justify-center text-rose-600 border border-rose-100"><AlertTriangle size={12} /></div>
                      <span className="text-lg font-black text-slate-800">1</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Overdue</span>
                  </div>
                  <div className="bg-white border border-emerald-100 rounded-xl p-3 flex flex-col shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-6 h-6 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600 border border-emerald-100"><CheckCircle2 size={12} /></div>
                      <span className="text-lg font-black text-slate-800">4</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Completed</span>
                  </div>
                </div>
              </div>

              {/* Next Due Maintenance */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">Next Due Maintenance</h3>
                  <button className="text-[10px] font-bold text-purple-600 hover:text-purple-700 transition-colors">View All &rarr;</button>
                </div>
                <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <span className="text-3xl font-black text-slate-800">18</span>
                    <div>
                      <h4 className="text-[11px] font-bold text-slate-800">Service & Maintenance</h4>
                      <p className="text-[10px] font-semibold text-slate-500 mt-0.5">Due: 24 Jun 2025 @ 1,250 Hrs</p>
                    </div>
                  </div>
                  <span className="inline-flex px-2 py-1 bg-amber-50 text-amber-600 border border-amber-200 rounded text-[9px] font-bold tracking-widest uppercase">Due Soon</span>
                </div>
              </div>

              {/* Hours & Usage */}
              <div>
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-3">Hours & Usage</h3>
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-3 grid grid-cols-4 gap-2">
                  <div className="flex flex-col items-center justify-center text-center p-2">
                    <Activity size={14} className="text-blue-500 mb-2" />
                    <span className="text-[11px] font-black text-slate-800 block">1,256.5 Hrs</span>
                    <span className="text-[9px] font-bold text-slate-500">Current Hours</span>
                  </div>
                  <div className="flex flex-col items-center justify-center text-center p-2 border-l border-slate-100">
                    <Calendar size={14} className="text-purple-500 mb-2" />
                    <span className="text-[11px] font-black text-slate-800 block">1,250 Hrs</span>
                    <span className="text-[9px] font-bold text-slate-500">Next Service (Due)</span>
                  </div>
                  <div className="flex flex-col items-center justify-center text-center p-2 border-l border-slate-100">
                    <TrendingUp size={14} className="text-emerald-500 mb-2" />
                    <span className="text-[11px] font-black text-slate-800 block">7.5 Hrs</span>
                    <span className="text-[9px] font-bold text-slate-500">Avg Daily Usage</span>
                  </div>
                  <div className="flex flex-col items-center justify-center text-center p-2 border-l border-slate-100">
                    <Clock size={14} className="text-slate-500 mb-2" />
                    <span className="text-[11px] font-black text-slate-800 block">1,256.5 Hrs</span>
                    <span className="text-[9px] font-bold text-slate-500">This Month</span>
                  </div>
                </div>
              </div>

              {/* Downtime Summary */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">Downtime Summary (FY 2024-2025)</h3>
                  <button className="text-[10px] font-bold text-purple-600 hover:text-purple-700 transition-colors">View Report &rarr;</button>
                </div>
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
                  <div className="grid grid-cols-2 gap-y-4 gap-x-2">
                    <div>
                      <span className="text-[10px] font-semibold text-slate-500 block mb-0.5">Total Downtime</span>
                      <span className="text-[11px] font-black text-slate-800">9.0 Hrs</span>
                    </div>
                    <div>
                      <span className="text-[10px] font-semibold text-slate-500 block mb-0.5">Breakdown Downtime</span>
                      <span className="text-[11px] font-black text-slate-800">0.0 Hrs</span>
                    </div>
                    <div>
                      <span className="text-[10px] font-semibold text-slate-500 block mb-0.5">Downtime</span>
                      <span className="text-[11px] font-black text-slate-800">9.0 Hrs</span>
                    </div>
                    <div>
                      <span className="text-[10px] font-semibold text-slate-500 block mb-0.5">Downtime Cost</span>
                      <span className="text-[11px] font-black text-slate-800">$1,125.00</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div>
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-3">Quick Actions</h3>
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                  <button className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 border-b border-slate-100 transition-colors text-left group">
                    <Calendar size={14} className="text-slate-400 group-hover:text-purple-600 transition-colors" />
                    <span className="text-[11px] font-bold text-slate-700 group-hover:text-purple-700">Schedule Maintenance</span>
                  </button>
                  <button className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 border-b border-slate-100 transition-colors text-left group">
                    <Wrench size={14} className="text-slate-400 group-hover:text-purple-600 transition-colors" />
                    <span className="text-[11px] font-bold text-slate-700 group-hover:text-purple-700">Log Unscheduled Maintenance</span>
                  </button>
                  <button className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 border-b border-slate-100 transition-colors text-left group">
                    <AlertTriangle size={14} className="text-slate-400 group-hover:text-purple-600 transition-colors" />
                    <span className="text-[11px] font-bold text-slate-700 group-hover:text-purple-700">Record Downtime</span>
                  </button>
                  <button className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 border-b border-slate-100 transition-colors text-left group">
                    <Package size={14} className="text-slate-400 group-hover:text-purple-600 transition-colors" />
                    <span className="text-[11px] font-bold text-slate-700 group-hover:text-purple-700">Request Parts / Material</span>
                  </button>
                  <button className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 border-b border-slate-100 transition-colors text-left group">
                    <Calendar size={14} className="text-slate-400 group-hover:text-purple-600 transition-colors" />
                    <span className="text-[11px] font-bold text-slate-700 group-hover:text-purple-700">View Maintenance Calendar</span>
                  </button>
                  <button className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 border-b border-slate-100 transition-colors text-left group">
                    <Clock size={14} className="text-slate-400 group-hover:text-purple-600 transition-colors" />
                    <span className="text-[11px] font-bold text-slate-700 group-hover:text-purple-700">View Service History</span>
                  </button>
                  <button className="w-full flex items-center gap-3 p-3 hover:bg-slate-50 transition-colors text-left group">
                    <Printer size={14} className="text-slate-400 group-hover:text-purple-600 transition-colors" />
                    <span className="text-[11px] font-bold text-slate-700 group-hover:text-purple-700">Print Maintenance Schedule</span>
                  </button>
                </div>
              </div>
              
            </div>
          </div>

          {/* DEVELOPER NOTES */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mt-6">
            <div className="p-4 border-b border-slate-100 flex items-center gap-2">
              <div className="bg-purple-600 p-1.5 rounded text-white">
                <Code size={14} />
              </div>
              <h3 className="text-[11px] font-black text-purple-700 uppercase tracking-widest">DEVELOPER NOTES - ASSET MAINTENANCE & SERVICE</h3>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6 p-4 sm:p-6">
              {/* Col 1 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">1</div> 
                  <span>PURPOSE</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Manage all maintenance, service and inspection tasks.</li>
                  <li className="pl-1">Track schedules, completion, downtime and costs.</li>
                  <li className="pl-1">Ensure asset reliability and compliance.</li>
                </ul>
              </div>
              
              {/* Col 2 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">2</div> 
                  <span>KEY FEATURES</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Schedule recurring maintenance & inspections.</li>
                  <li className="pl-1">Track next due by hours, time or usage.</li>
                  <li className="pl-1">Log service history, parts, labour and downtime.</li>
                  <li className="pl-1">Set reminders and alerts before due dates.</li>
                </ul>
              </div>
              
              {/* Col 3 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">3</div> 
                  <span>AUTOMATION & ALERTS</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Auto-calculate next due based on rules.</li>
                  <li className="pl-1">Alert for due soon, overdue & expiring items.</li>
                  <li className="pl-1">AI predicts potential issues from history.</li>
                  <li className="pl-1">Escalate critical overdue items.</li>
                </ul>
              </div>

              {/* Col 4 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">4</div> 
                  <span>PERMISSIONS</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Super Admin: Full access.</li>
                  <li className="pl-1">Admin/Manager: Create, edit, approve.</li>
                  <li className="pl-1">Workshop: Update maintenance tasks.</li>
                  <li className="pl-1">Staff: View assigned maintenance.</li>
                </ul>
              </div>

              {/* Col 5 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">5</div> 
                  <span>DATA SOURCES</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Assets module.</li>
                  <li className="pl-1">Maintenance module.</li>
                  <li className="pl-1">Parts & Inventory module.</li>
                  <li className="pl-1">Downtime & Costs module.</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-slate-50/80 border-t border-slate-100 p-4 flex items-center justify-between">
              <span className="text-[9px] font-bold text-slate-500">All times shown in your local time (AEST)</span>
              <div className="flex items-center gap-2 text-[9px] font-bold text-slate-500">
                Data auto-refreshes every 5 minutes
                <RefreshCw size={10} className="text-slate-400" />
              </div>
            </div>
          </div>
        </div>
      )}


      {activeTab === 'Compliance & Documents' && (
        <div className="space-y-6">
          {/* Inner Navigation Tabs */}
          <div className="flex items-center gap-6 border-b border-slate-200 overflow-x-auto custom-scrollbar">
            {['All Documents', 'Compliance', 'Certificates & Licences', 'Insurance', 'Maintenance Records', 'Inspection Reports', 'Other Documents'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveDocTab(tab)}
                className={`pb-3 text-xs font-bold transition-all border-b-2 cursor-pointer whitespace-nowrap ${activeDocTab === tab ? 'text-purple-700 border-purple-700' : 'text-slate-500 border-transparent hover:text-slate-800'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
            
            {/* LEFT COLUMN: TABLE */}
            <div className="flex flex-col space-y-4">
              
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">ALL DOCUMENTS ({assetDocuments.length})</h3>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full">
                {/* Table Header Controls */}
                <div className="p-4 border-b border-slate-100 flex flex-wrap gap-3 items-center justify-between">
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="relative">
                      <Search size={14} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
                      <input type="text" placeholder="Search documents..." className="pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-[11px] font-semibold text-slate-700 outline-none focus:border-purple-500 w-48" />
                    </div>
                    
                    <button className="flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition-colors bg-white">
                      All Categories <ChevronDown size={14} className="text-slate-400" />
                    </button>
                    <button className="flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition-colors bg-white">
                      All Status <ChevronDown size={14} className="text-slate-400" />
                    </button>
                    <button className="flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition-colors bg-white">
                      All Expiry Status <ChevronDown size={14} className="text-slate-400" />
                    </button>
                    
                    <button className="flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition-colors bg-white">
                      <Filter size={14} /> Filters
                    </button>
                  </div>
                  
                  <button className="flex items-center gap-2 px-4 py-2 bg-purple-50 text-purple-700 rounded-lg text-[11px] font-bold hover:bg-purple-100 transition-colors">
                    <Upload size={14} /> Upload Document
                  </button>
                </div>

                {/* Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse min-w-[1000px]">
                    <thead>
                      <tr className="border-b border-slate-100 bg-slate-50/50">
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Document Name</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Category</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Document Type</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Issue Date</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Expiry Date</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Status</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Expiry Status</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider whitespace-nowrap">Uploaded By</th>
                        <th className="px-5 py-4 text-[10px] font-black text-slate-800 uppercase tracking-wider text-center whitespace-nowrap">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {documentsList.map((doc, idx) => (
                        <tr key={idx} className="border-b border-slate-50 hover:bg-slate-50/80 transition-colors">
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <div className="flex items-start gap-3">
                              <div className="mt-0.5 text-purple-600 bg-purple-50 p-1.5 rounded"><FileIcon size={14} /></div>
                              <div>
                                <h4 className="text-[11px] font-bold text-slate-800">{doc.name}</h4>
                                <p className="text-[10px] font-medium text-slate-500 mt-0.5">{doc.file}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <span className={`text-[11px] font-bold ${doc.category === 'Registration' ? 'text-blue-600' : doc.category === 'Maintenance' ? 'text-indigo-600' : doc.category === 'Inspection' ? 'text-teal-600' : doc.category === 'Licence' ? 'text-emerald-600' : doc.category === 'Insurance' ? 'text-cyan-600' : doc.category === 'Compliance' ? 'text-purple-600' : doc.category === 'Warranty' ? 'text-rose-600' : 'text-slate-600'}`}>
                              {doc.category}
                            </span>
                          </td>
                          <td className="px-5 py-3.5 text-[11px] font-semibold text-slate-700 whitespace-nowrap">{doc.type}</td>
                          <td className="px-5 py-3.5 text-[11px] font-semibold text-slate-700 whitespace-nowrap">{doc.issueDate}</td>
                          <td className="px-5 py-3.5 text-[11px] font-semibold text-slate-700 whitespace-nowrap">{doc.expiryDate}</td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <span className={`inline-flex px-1.5 py-0.5 rounded text-[9px] font-bold tracking-widest uppercase border ${doc.status === 'Active' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-rose-50 text-rose-600 border-rose-200'}`}>
                              {doc.status}
                            </span>
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <span className={`text-[10px] font-bold ${doc.expiryStatus === 'Compliant' ? 'text-emerald-500' : doc.expiryStatus === 'Expiring Soon' ? 'text-amber-500' : doc.expiryStatus === 'Expired' ? 'text-rose-500' : 'text-slate-400'}`}>
                              {doc.expiryStatus}
                            </span>
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap">
                            <h4 className="text-[11px] font-bold text-slate-800">{doc.uploader}</h4>
                            <p className="text-[10px] font-medium text-slate-500 mt-0.5">{doc.uploadDate}</p>
                          </td>
                          <td className="px-5 py-3.5 whitespace-nowrap relative">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                title="View Document Details"
                                onClick={() => setViewDocModal(doc)}
                                className="w-7 h-7 rounded-md bg-slate-100 text-slate-600 hover:bg-purple-100 hover:text-purple-700 flex items-center justify-center transition-colors cursor-pointer"
                              >
                                <Eye size={14} />
                              </button>

                              <button
                                title="Download Document"
                                onClick={() => triggerToast('Document Downloaded', `Downloading file ${doc.file}`)}
                                className="w-7 h-7 rounded-md bg-slate-100 text-slate-600 hover:bg-purple-100 hover:text-purple-700 flex items-center justify-center transition-colors cursor-pointer"
                              >
                                <Download size={14} />
                              </button>

                              <div className="relative">
                                <button
                                  title="More Actions"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setDocMenuIndex(docMenuIndex === idx ? null : idx);
                                  }}
                                  className={`w-7 h-7 rounded-md ${docMenuIndex === idx ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600 hover:bg-purple-100 hover:text-purple-700'} flex items-center justify-center transition-colors cursor-pointer`}
                                >
                                  <MoreHorizontal size={14} />
                                </button>

                                {docMenuIndex === idx && (
                                  <>
                                    <div className="fixed inset-0 z-40" onClick={() => setDocMenuIndex(null)} />
                                    <div className="absolute right-0 top-full mt-1 w-44 bg-white rounded-xl shadow-xl border border-slate-200 p-1.5 z-50 flex flex-col gap-0.5 text-xs font-semibold text-slate-700">
                                      <button
                                        onClick={() => { setViewDocModal(doc); setDocMenuIndex(null); }}
                                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                      >
                                        👁️ View Details
                                      </button>
                                      <button
                                        onClick={() => { triggerToast('Document Downloaded', `Downloading ${doc.file}`); setDocMenuIndex(null); }}
                                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                      >
                                        📥 Download File
                                      </button>
                                      <button
                                        onClick={() => { setEditDocModal({ ...doc, index: idx }); setDocMenuIndex(null); }}
                                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                      >
                                        ✏️ Edit Details
                                      </button>
                                      <div className="h-px bg-slate-100 my-1" />
                                      <button
                                        onClick={() => {
                                          setDocumentsList(prev => prev.filter((_, i) => i !== idx));
                                          triggerToast('Document Deleted', `Document "${doc.name}" removed.`);
                                          setDocMenuIndex(null);
                                        }}
                                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-rose-50 text-rose-600 text-left w-full cursor-pointer"
                                      >
                                        ❌ Delete Document
                                      </button>
                                    </div>
                                  </>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                {/* Pagination Footer */}
                <div className="p-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium bg-slate-50/30">
                  <span>Showing 1 to {assetDocuments.length} of {assetDocuments.length} documents</span>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <button className="w-6 h-6 flex items-center justify-center rounded text-slate-400"><ChevronLeft size={14} /></button>
                      <button className="w-6 h-6 flex items-center justify-center rounded bg-purple-700 text-white font-bold">1</button>
                      <button className="w-6 h-6 flex items-center justify-center rounded text-slate-400"><ChevronRight size={14} /></button>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-700 text-[10px]">10 / page</span>
                      <ChevronDown size={14} className="text-slate-400" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN: INSIGHTS & ALERTS */}
            <div className="space-y-6">
              
              {/* Compliance Overview */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">Compliance Overview</h3>
                  <button className="text-[10px] font-bold text-purple-600 hover:text-purple-700 transition-colors">View Report &rarr;</button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white border border-emerald-100 rounded-xl p-3 flex flex-col shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-6 h-6 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600 border border-emerald-100"><CheckCircle2 size={12} /></div>
                      <span className="text-lg font-black text-slate-800">6</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Compliant</span>
                  </div>
                  <div className="bg-white border border-amber-100 rounded-xl p-3 flex flex-col shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-6 h-6 rounded-full bg-amber-50 flex items-center justify-center text-amber-600 border border-amber-100"><ShieldAlert size={12} /></div>
                      <span className="text-lg font-black text-slate-800">1</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Expiring Soon</span>
                  </div>
                  <div className="bg-white border border-rose-100 rounded-xl p-3 flex flex-col shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-6 h-6 rounded-full bg-rose-50 flex items-center justify-center text-rose-600 border border-rose-100"><AlertTriangle size={12} /></div>
                      <span className="text-lg font-black text-slate-800">1</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Expired</span>
                  </div>
                  <div className="bg-white border border-blue-100 rounded-xl p-3 flex flex-col shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 border border-blue-100"><RefreshCw size={12} /></div>
                      <span className="text-lg font-black text-slate-800">2</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Not Required</span>
                  </div>
                </div>
              </div>

              {/* Next Expiry */}
              <div>
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-3">Next Expiry</h3>
                <div className="bg-white border border-amber-200 rounded-xl p-4 flex items-center justify-between shadow-sm shadow-amber-100/50">
                  <div className="flex items-center gap-3">
                    <div className="text-amber-500"><Calendar size={20} /></div>
                    <div>
                      <h4 className="text-[11px] font-bold text-slate-800">Service & Maintenance</h4>
                      <p className="text-[10px] font-semibold text-slate-500 mt-0.5">Due: 24 Jun 2025</p>
                    </div>
                  </div>
                  <span className="text-[11px] font-black text-amber-600">in 18 days</span>
                </div>
                <div className="mt-2 text-right">
                  <button className="text-[10px] font-bold text-purple-600 hover:text-purple-700 transition-colors">View All Alerts &rarr;</button>
                </div>
              </div>

              {/* Compliance Alerts */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">Compliance Alerts</h3>
                  <button className="text-[10px] font-bold text-purple-600 hover:text-purple-700 transition-colors">View All &rarr;</button>
                </div>
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="p-4 border-b border-slate-50 flex items-center justify-between bg-amber-50/50">
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 text-amber-500"><AlertTriangle size={14} /></div>
                      <div>
                        <h4 className="text-[11px] font-bold text-slate-800">Service & Maintenance</h4>
                        <p className="text-[10px] font-semibold text-slate-500 mt-0.5">Due in 18 days</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-700">24 Jun 2025</span>
                  </div>
                  <div className="p-4 border-b border-slate-50 flex items-center justify-between bg-amber-50/30">
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 text-amber-500"><AlertTriangle size={14} /></div>
                      <div>
                        <h4 className="text-[11px] font-bold text-slate-800">Annual Inspection Report</h4>
                        <p className="text-[10px] font-semibold text-slate-500 mt-0.5">Due in 61 days</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-700">24 Aug 2025</span>
                  </div>
                  <div className="p-4 flex items-center justify-between bg-rose-50/50">
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 text-rose-500"><ShieldAlert size={14} /></div>
                      <div>
                        <h4 className="text-[11px] font-bold text-rose-700">Load Test Certificate</h4>
                        <p className="text-[10px] font-semibold text-rose-500 mt-0.5">Expired 131 days</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-rose-700">14 Feb 2025</span>
                  </div>
                </div>
              </div>

              {/* Document Categories */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">Document Categories</h3>
                  <button className="text-[10px] font-bold text-purple-600 hover:text-purple-700 transition-colors">View All &rarr;</button>
                </div>
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-2">
                  <div className="flex items-center justify-between px-3 py-2.5 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <FileIcon size={14} className="text-blue-500" />
                      <span className="text-[11px] font-bold text-slate-700">Registration</span>
                    </div>
                    <span className="text-[11px] font-black text-slate-800">1</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2.5 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <FileIcon size={14} className="text-indigo-500" />
                      <span className="text-[11px] font-bold text-slate-700">Maintenance</span>
                    </div>
                    <span className="text-[11px] font-black text-slate-800">1</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2.5 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <FileIcon size={14} className="text-teal-500" />
                      <span className="text-[11px] font-bold text-slate-700">Inspection</span>
                    </div>
                    <span className="text-[11px] font-black text-slate-800">1</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2.5 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <FileIcon size={14} className="text-emerald-500" />
                      <span className="text-[11px] font-bold text-slate-700">Licence</span>
                    </div>
                    <span className="text-[11px] font-black text-slate-800">1</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2.5 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <FileIcon size={14} className="text-cyan-500" />
                      <span className="text-[11px] font-bold text-slate-700">Insurance</span>
                    </div>
                    <span className="text-[11px] font-black text-slate-800">1</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2.5 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <FileIcon size={14} className="text-purple-500" />
                      <span className="text-[11px] font-bold text-slate-700">Compliance</span>
                    </div>
                    <span className="text-[11px] font-black text-slate-800">2</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2.5 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors">
                    <div className="flex items-center gap-3">
                      <FileIcon size={14} className="text-rose-500" />
                      <span className="text-[11px] font-bold text-slate-700">Warranty</span>
                    </div>
                    <span className="text-[11px] font-black text-slate-800">1</span>
                  </div>
                  <div className="flex items-center justify-between px-3 py-2.5 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors border-t border-slate-100 mt-1">
                    <div className="flex items-center gap-3">
                      <FileIcon size={14} className="text-slate-400" />
                      <span className="text-[11px] font-bold text-slate-700">Other</span>
                    </div>
                    <span className="text-[11px] font-black text-slate-800">1</span>
                  </div>
                </div>
              </div>
              
            </div>
          </div>

          {/* DEVELOPER NOTES */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mt-6">
            <div className="p-4 border-b border-slate-100 flex items-center gap-2">
              <div className="bg-purple-600 p-1.5 rounded text-white">
                <Code size={14} />
              </div>
              <h3 className="text-[11px] font-black text-purple-700 uppercase tracking-widest">DEVELOPER NOTES - ASSET DOCUMENTS & COMPLIANCE</h3>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6 p-4 sm:p-6">
              {/* Col 1 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">1</div> 
                  <span>PURPOSE</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Central repository for all asset related documents.</li>
                  <li className="pl-1">Track compliance, certificates, expiry and alerts.</li>
                  <li className="pl-1">Ensure assets remain compliant and operational.</li>
                </ul>
              </div>
              
              {/* Col 2 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">2</div> 
                  <span>KEY FEATURES</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Upload, view, download and manage documents.</li>
                  <li className="pl-1">Categorised documents with expiry tracking.</li>
                  <li className="pl-1">Compliance status with alerts and notifications.</li>
                  <li className="pl-1">Filter by category, status and expiry.</li>
                </ul>
              </div>
              
              {/* Col 3 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">3</div> 
                  <span>AUTOMATION & ALERTS</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Auto-detect expiry from document (AI add-on).</li>
                  <li className="pl-1">Auto reminders before expiry.</li>
                  <li className="pl-1">Escalate overdue items.</li>
                  <li className="pl-1">Dashboard and notification alerts.</li>
                </ul>
              </div>

              {/* Col 4 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">4</div> 
                  <span>PERMISSIONS</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Super Admin: Full access.</li>
                  <li className="pl-1">Admin/Manager: Create, edit, upload.</li>
                  <li className="pl-1">Dispatch/Warehouse: View relevant only.</li>
                  <li className="pl-1">Staff: View assigned asset documents.</li>
                </ul>
              </div>

              {/* Col 5 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">5</div> 
                  <span>DATA SOURCES</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Assets module.</li>
                  <li className="pl-1">Maintenance module.</li>
                  <li className="pl-1">Compliance module.</li>
                  <li className="pl-1">Documents & Activity logs.</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-slate-50/80 border-t border-slate-100 p-4 flex items-center justify-between">
              <span className="text-[9px] font-bold text-slate-500">All times shown in your local time (AEST)</span>
              <div className="flex items-center gap-2 text-[9px] font-bold text-slate-500">
                Data auto-refreshes every 5 minutes
                <RefreshCw size={10} className="text-slate-400" />
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'Specifications' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
          <h3 className="text-sm font-black text-slate-900 mb-4 uppercase tracking-wider">Technical Specifications</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-xs">
            <div className="border border-slate-100 p-4 rounded-xl">
              <h4 className="font-bold text-purple-700 mb-2">Engine & Power</h4>
              <div className="space-y-1.5 text-slate-600">
                <div className="flex justify-between"><span>Engine Type:</span><span className="font-semibold text-slate-900">Toyota 1DZ-II Diesel</span></div>
                <div className="flex justify-between"><span>Displacement:</span><span className="font-semibold text-slate-900">2,486 cc</span></div>
                <div className="flex justify-between"><span>Rated Output:</span><span className="font-semibold text-slate-900">40 kW / 2400 rpm</span></div>
                <div className="flex justify-between"><span>Fuel Capacity:</span><span className="font-semibold text-slate-900">60 Litres</span></div>
              </div>
            </div>
            <div className="border border-slate-100 p-4 rounded-xl">
              <h4 className="font-bold text-purple-700 mb-2">Dimensions & Capacity</h4>
              <div className="space-y-1.5 text-slate-600">
                <div className="flex justify-between"><span>Load Capacity:</span><span className="font-semibold text-slate-900">2,500 kg</span></div>
                <div className="flex justify-between"><span>Lift Height:</span><span className="font-semibold text-slate-900">4,500 mm</span></div>
                <div className="flex justify-between"><span>Overall Weight:</span><span className="font-semibold text-slate-900">3,780 kg</span></div>
                <div className="flex justify-between"><span>Fork Length:</span><span className="font-semibold text-slate-900">1,070 mm</span></div>
              </div>
            </div>
            <div className="border border-slate-100 p-4 rounded-xl">
              <h4 className="font-bold text-purple-700 mb-2">Tires & Hydraulics</h4>
              <div className="space-y-1.5 text-slate-600">
                <div className="flex justify-between"><span>Tire Type:</span><span className="font-semibold text-slate-900">Solid Pneumatic</span></div>
                <div className="flex justify-between"><span>Front Tires:</span><span className="font-semibold text-slate-900">7.00-12-12PR</span></div>
                <div className="flex justify-between"><span>Rear Tires:</span><span className="font-semibold text-slate-900">6.00-9-10PR</span></div>
                <div className="flex justify-between"><span>Attachment:</span><span className="font-semibold text-slate-900">Integrated Side Shift</span></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MAIN SECTION BELOW TABS: COSTS & DEPRECIATION TAB */}
      {activeTab === 'Costs & Depreciation' && (
        <div className="space-y-6">
          {/* Inner Navigation Tabs */}
          <div className="flex items-center gap-6 border-b border-slate-200 overflow-x-auto custom-scrollbar">
            {['Cost Overview', 'All Costs & Expenses', 'Depreciation Schedule', 'Cost by Category', 'Cost by Branch / Location', 'Tax & Compliance'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveCostTab(tab)}
                className={`pb-3 text-xs font-bold transition-all border-b-2 cursor-pointer whitespace-nowrap ${activeCostTab === tab ? 'text-purple-700 border-purple-700' : 'text-slate-500 border-transparent hover:text-slate-800'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
            
            {/* Left Column (Table) */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-full">
              
              {/* Filter Bar */}
              <div className="p-3.5 border-b border-slate-100 flex items-center justify-between gap-2 bg-white overflow-x-auto custom-scrollbar">
                <div className="flex items-center gap-2 flex-nowrap shrink-0">
                  <div className="relative">
                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Search costs..." 
                      className="pl-9 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold w-[160px] outline-none focus:border-purple-500"
                      value={costSearch}
                      onChange={(e) => setCostSearch(e.target.value)}
                    />
                  </div>
                  <select className="px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-bold text-slate-700 outline-none bg-white min-w-[140px] whitespace-nowrap">
                    <option>All Cost Categories</option>
                    <option>Maintenance</option>
                    <option>Operating</option>
                  </select>
                  <select className="px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-bold text-slate-700 outline-none bg-white min-w-[125px] whitespace-nowrap">
                    <option>All Cost Types</option>
                    <option>Fuel</option>
                    <option>Service</option>
                  </select>
                  <div className="relative">
                    <button
                      onClick={() => setIsDatePopoverOpen(!isDatePopoverOpen)}
                      className={`flex items-center gap-1.5 px-2.5 py-1.5 border rounded-lg text-xs font-bold transition-colors bg-white whitespace-nowrap cursor-pointer ${isDatePopoverOpen ? 'border-purple-600 text-purple-700 bg-purple-50' : 'border-slate-200 text-slate-700 hover:bg-slate-50'}`}
                    >
                      {costDateRange} <Calendar size={12} className="text-purple-600" />
                    </button>

                    {isDatePopoverOpen && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => setIsDatePopoverOpen(false)} />
                        <div className="absolute left-0 top-full mt-1 w-64 bg-white rounded-2xl shadow-2xl border border-slate-200 p-3 z-50 flex flex-col gap-2 text-xs font-semibold text-slate-700">
                          <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">SELECT DATE RANGE</div>
                          <div className="flex flex-col gap-1">
                            {[
                              '01 Jul 2024 - 30 Jun 2025 (FY 24-25)',
                              '01 Jul 2023 - 30 Jun 2024 (FY 23-24)',
                              'Last 30 Days (22 Jun - 22 Jul 2026)',
                              'Last 90 Days (22 Apr - 22 Jul 2026)',
                              'Year to Date (YTD 2026)',
                              'All Time'
                            ].map((range) => {
                              const cleanRange = range.split(' (')[0];
                              const isSelected = costDateRange === cleanRange || costDateRange === range;
                              return (
                                <button
                                  key={range}
                                  onClick={() => {
                                    setCostDateRange(cleanRange);
                                    triggerToast('Date Range Filtered', `Displaying records for ${cleanRange}`);
                                    setIsDatePopoverOpen(false);
                                  }}
                                  className={`flex items-center justify-between px-2.5 py-2 rounded-xl text-left font-bold transition-colors cursor-pointer ${isSelected ? 'bg-purple-100 text-purple-700' : 'hover:bg-slate-100 text-slate-700'}`}
                                >
                                  <span className="text-[11px]">{range}</span>
                                  {isSelected && <span className="text-purple-600 font-bold">✓</span>}
                                </button>
                              );
                            })}
                          </div>

                          <div className="h-px bg-slate-100 my-1" />
                          
                          {/* Custom date range input */}
                          <div className="space-y-2 p-1">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">CUSTOM RANGE</span>
                            <div className="grid grid-cols-2 gap-1.5">
                              <input type="date" defaultValue="2024-07-01" className="px-2 py-1 border border-slate-200 rounded-lg text-[10px] outline-none font-semibold text-slate-700" />
                              <input type="date" defaultValue="2025-06-30" className="px-2 py-1 border border-slate-200 rounded-lg text-[10px] outline-none font-semibold text-slate-700" />
                            </div>
                            <button
                              onClick={() => {
                                setCostDateRange('01 Jul 2024 - 30 Jun 2025');
                                triggerToast('Custom Date Applied', 'Filtered by custom date range');
                                setIsDatePopoverOpen(false);
                              }}
                              className="w-full py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-[11px] font-bold transition-all cursor-pointer text-center"
                            >
                              Apply Custom Range
                            </button>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                  <button className="flex items-center gap-1.5 px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-50 bg-white whitespace-nowrap cursor-pointer">
                    <Filter size={12} /> Filters
                  </button>
                </div>
                
                <div className="flex items-center gap-1.5 shrink-0">
                  <button className="flex items-center gap-1.5 px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-50 bg-white whitespace-nowrap cursor-pointer">
                    <Download size={12} /> Export
                  </button>
                  <button className="p-1.5 border border-slate-200 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-50 bg-white cursor-pointer">
                    <RefreshCw size={12} />
                  </button>
                </div>
              </div>

              {/* Table */}
              <div className="px-4 py-3 bg-slate-50/50 border-b border-slate-100 flex items-center justify-between">
                <span className="text-[10px] font-black text-slate-800 uppercase tracking-widest">COST & EXPENSES ({costsList.length})</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[1000px]">
                  <thead>
                    <tr className="bg-white border-b border-slate-200">
                      <th className="px-4 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap">Date</th>
                      <th className="px-4 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap">Category</th>
                      <th className="px-4 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap">Cost Type</th>
                      <th className="px-4 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap min-w-[160px]">Description</th>
                      <th className="px-4 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap">Reference / Invoice</th>
                      <th className="px-4 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap">Branch / Location</th>
                      <th className="px-4 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap">Amount (AUD)</th>
                      <th className="px-4 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap">Tax (AUD)</th>
                      <th className="px-4 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap">Total (AUD)</th>
                      <th className="px-4 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest text-center whitespace-nowrap">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {costsList.map((row, idx) => (
                      <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50 transition-colors group">
                        <td className="px-4 py-3 text-[11px] font-semibold text-slate-700 whitespace-nowrap">{row.date}</td>
                        <td className="px-4 py-3 text-[11px] whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${row.color === 'purple' ? 'bg-purple-50 text-purple-600' : row.color === 'emerald' ? 'bg-emerald-50 text-emerald-600' : row.color === 'blue' ? 'bg-blue-50 text-blue-600' : row.color === 'orange' ? 'bg-orange-50 text-orange-600' : 'bg-slate-100 text-slate-600'}`}>
                            {row.category}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-[11px] font-semibold text-slate-700 whitespace-nowrap">{row.type}</td>
                        <td className="px-4 py-3 text-[11px] font-semibold text-slate-800 whitespace-nowrap">{row.desc}</td>
                        <td className="px-4 py-3 text-[11px] font-semibold text-slate-700 whitespace-nowrap">{row.ref}</td>
                        <td className="px-4 py-3 text-[11px] font-semibold text-slate-600 whitespace-nowrap">{row.loc}</td>
                        <td className="px-4 py-3 text-[11px] font-semibold text-slate-900 whitespace-nowrap">{row.amount}</td>
                        <td className="px-4 py-3 text-[11px] font-semibold text-slate-500 whitespace-nowrap">{row.tax}</td>
                        <td className="px-4 py-3 text-[11px] font-black text-slate-900 whitespace-nowrap">{row.total}</td>
                        <td className="px-4 py-3 text-center whitespace-nowrap relative">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              title="View Cost Details"
                              onClick={() => setViewCostModal(row)}
                              className="w-7 h-7 rounded-md bg-slate-100 text-slate-600 hover:bg-purple-100 hover:text-purple-700 flex items-center justify-center transition-colors cursor-pointer"
                            >
                              <Eye size={14} />
                            </button>

                            <div className="relative">
                              <button
                                title="More Actions"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setCostMenuIndex(costMenuIndex === idx ? null : idx);
                                }}
                                className={`w-7 h-7 rounded-md ${costMenuIndex === idx ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600 hover:bg-purple-100 hover:text-purple-700'} flex items-center justify-center transition-colors cursor-pointer`}
                              >
                                <MoreHorizontal size={14} />
                              </button>

                              {costMenuIndex === idx && (
                                <>
                                  <div className="fixed inset-0 z-40" onClick={() => setCostMenuIndex(null)} />
                                  <div className="absolute right-0 top-full mt-1 w-44 bg-white rounded-xl shadow-xl border border-slate-200 p-1.5 z-50 flex flex-col gap-0.5 text-xs font-semibold text-slate-700">
                                    <button
                                      onClick={() => { setViewCostModal(row); setCostMenuIndex(null); }}
                                      className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                    >
                                      👁️ View Details
                                    </button>
                                    <button
                                      onClick={() => { triggerToast('Invoice Downloaded', `Downloading invoice ${row.ref}`); setCostMenuIndex(null); }}
                                      className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                    >
                                      📄 Download Invoice
                                    </button>
                                    <button
                                      onClick={() => { setEditCostModal({ ...row, index: idx }); setCostMenuIndex(null); }}
                                      className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 text-left w-full cursor-pointer"
                                    >
                                      ✏️ Edit Record
                                    </button>
                                    <div className="h-px bg-slate-100 my-1" />
                                    <button
                                      onClick={() => {
                                        setCostsList(prev => prev.filter((_, i) => i !== idx));
                                        triggerToast('Cost Deleted', `Deleted cost record ${row.ref}`);
                                        setCostMenuIndex(null);
                                      }}
                                      className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg hover:bg-rose-50 text-rose-600 text-left w-full cursor-pointer"
                                    >
                                      ❌ Delete Record
                                    </button>
                                  </div>
                                </>
                              )}
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-semibold text-slate-500 mt-auto bg-white">
                <div>Showing 1 to 11 of 11 costs</div>
                <div className="flex items-center gap-1">
                  <button className="w-6 h-6 rounded flex items-center justify-center border border-slate-200 hover:bg-slate-50">&lt;</button>
                  <button className="w-6 h-6 rounded flex items-center justify-center border border-purple-200 bg-purple-50 text-purple-700 font-bold">1</button>
                  <button className="w-6 h-6 rounded flex items-center justify-center border border-slate-200 hover:bg-slate-50">&gt;</button>
                </div>
                <select className="border border-slate-200 rounded px-2 py-1 outline-none text-slate-700 font-bold bg-white">
                  <option>10 / page</option>
                  <option>25 / page</option>
                </select>
              </div>
            </div>

            {/* Right Column (Sidebar Summaries) */}
            <div className="flex flex-col gap-6">
              
              {/* Cost Summary Section */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">COST SUMMARY (FY 2024-2025)</h4>
                  <span className="text-[9px] font-bold text-purple-600 cursor-pointer hover:underline">View Report →</span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="border border-slate-100 rounded-xl p-3 bg-emerald-50/40 flex flex-col items-center justify-center text-center">
                    <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-1.5">
                      <CheckCircle2 size={16} />
                    </div>
                    <span className="text-xs font-black text-slate-900">$3,850.00</span>
                    <span className="text-[9px] font-semibold text-slate-400 mt-0.5 uppercase">Total Cost (YTD)</span>
                  </div>

                  <div className="border border-slate-100 rounded-xl p-3 bg-blue-50/40 flex flex-col items-center justify-center text-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mb-1.5">
                      <Activity size={16} />
                    </div>
                    <span className="text-xs font-black text-slate-900">$2,150.00</span>
                    <span className="text-[9px] font-semibold text-slate-400 mt-0.5 uppercase">Operating Cost</span>
                  </div>

                  <div className="border border-slate-100 rounded-xl p-3 bg-amber-50/40 flex flex-col items-center justify-center text-center">
                    <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mb-1.5">
                      <Wrench size={16} />
                    </div>
                    <span className="text-xs font-black text-slate-900">$1,250.00</span>
                    <span className="text-[9px] font-semibold text-slate-400 mt-0.5 uppercase">Maintenance Cost</span>
                  </div>

                  <div className="border border-slate-100 rounded-xl p-3 bg-slate-50 flex flex-col items-center justify-center text-center">
                    <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center mb-1.5">
                      <Layers size={16} />
                    </div>
                    <span className="text-xs font-black text-slate-900">$450.00</span>
                    <span className="text-[9px] font-semibold text-slate-400 mt-0.5 uppercase">Other Cost</span>
                  </div>
                </div>
              </div>

              {/* Depreciation Summary */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">DEPRECIATION SUMMARY</h4>
                  <span className="text-[9px] font-bold text-purple-600 cursor-pointer hover:underline">View Report →</span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {/* Card 1 */}
                  <div className="bg-slate-50 rounded-xl border border-slate-100 p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 flex items-center justify-center bg-purple-100 text-purple-600 rounded">
                        <DollarSign size={12} strokeWidth={3} />
                      </div>
                      <span className="text-xs font-black text-slate-900 leading-none tracking-tight">$38,500</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest pl-1">Purchase Price</span>
                  </div>
                  {/* Card 2 */}
                  <div className="bg-slate-50 rounded-xl border border-slate-100 p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 flex items-center justify-center bg-blue-100 text-blue-600 rounded">
                        <Calendar size={12} strokeWidth={3} />
                      </div>
                      <span className="text-xs font-black text-slate-900 leading-none tracking-tight">15 Mar 2022</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest pl-1">Start Date</span>
                  </div>
                  {/* Card 3 */}
                  <div className="bg-slate-50 rounded-xl border border-slate-100 p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 flex items-center justify-center bg-amber-100 text-amber-600 rounded">
                        <Activity size={12} strokeWidth={3} />
                      </div>
                      <span className="text-xs font-black text-slate-900 leading-none tracking-tight">$5,000</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest pl-1">Residual Value</span>
                  </div>
                  {/* Card 4 */}
                  <div className="bg-slate-50 rounded-xl border border-slate-100 p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 flex items-center justify-center bg-rose-100 text-rose-600 rounded">
                        <TrendingUp size={12} strokeWidth={3} className="transform rotate-180" />
                      </div>
                      <span className="text-xs font-black text-slate-900 leading-none tracking-tight">$18,460</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest pl-1">Accum. Deprec.</span>
                  </div>
                  {/* Card 5 */}
                  <div className="bg-slate-50 rounded-xl border border-slate-100 p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 flex items-center justify-center bg-emerald-100 text-emerald-600 rounded">
                        <Clock size={12} strokeWidth={3} />
                      </div>
                      <span className="text-xs font-black text-slate-900 leading-none tracking-tight">5 Years</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest pl-1">Useful Life</span>
                  </div>
                  {/* Card 6 */}
                  <div className="bg-slate-50 rounded-xl border border-slate-100 p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 flex items-center justify-center bg-indigo-100 text-indigo-600 rounded">
                        <DollarSign size={12} strokeWidth={3} />
                      </div>
                      <span className="text-xs font-black text-slate-900 leading-none tracking-tight">$20,040</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest pl-1">Book Value</span>
                  </div>
                  {/* Card 7 */}
                  <div className="bg-slate-50 rounded-xl border border-slate-100 p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 flex items-center justify-center bg-slate-200 text-slate-600 rounded">
                        <Layers size={12} strokeWidth={3} />
                      </div>
                      <span className="text-xs font-black text-slate-900 leading-none tracking-tight">Straight Line</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest pl-1">Method</span>
                  </div>
                  {/* Card 8 */}
                  <div className="bg-slate-50 rounded-xl border border-slate-100 p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 flex items-center justify-center bg-emerald-100 text-emerald-600 rounded">
                        <Activity size={12} strokeWidth={3} />
                      </div>
                      <span className="text-xs font-black text-slate-900 leading-none tracking-tight">$7,700</span>
                    </div>
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest pl-1">Deprec. (YTD)</span>
                  </div>
                </div>
              </div>

              {/* Chart: Cost By Category */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">COST BY CATEGORY (FY 2024-2025)</h4>
                  <span className="text-[9px] font-bold text-purple-600 cursor-pointer hover:underline">View Chart →</span>
                </div>
                <div className="flex items-center gap-4">
                  {/* Custom Donut Chart matching screenshot */}
                  <div className="relative flex items-center justify-center w-24 h-24 shrink-0">
                    <svg width="96" height="96" className="transform -rotate-90">
                      <circle cx="48" cy="48" r="38" fill="transparent" stroke="#E2E8F0" strokeWidth="12" />
                      <circle cx="48" cy="48" r="38" fill="transparent" stroke="#10B981" strokeWidth="12" strokeDasharray="133 238" strokeDashoffset="0" />
                      <circle cx="48" cy="48" r="38" fill="transparent" stroke="#F59E0B" strokeWidth="12" strokeDasharray="77 238" strokeDashoffset="-133" />
                      <circle cx="48" cy="48" r="38" fill="transparent" stroke="#EF4444" strokeWidth="12" strokeDasharray="18 238" strokeDashoffset="-210" />
                      <circle cx="48" cy="48" r="38" fill="transparent" stroke="#8B5CF6" strokeWidth="12" strokeDasharray="6 238" strokeDashoffset="-228" />
                      <circle cx="48" cy="48" r="38" fill="transparent" stroke="#64748B" strokeWidth="12" strokeDasharray="4 238" strokeDashoffset="-234" />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-sm font-black text-slate-900 leading-tight">$3,850</span>
                      <span className="text-[7px] font-bold text-slate-400 uppercase tracking-widest">Total Cost<br/>(YTD)</span>
                    </div>
                  </div>
                  {/* Legend */}
                  <div className="flex-1 space-y-1.5">
                    <div className="flex justify-between items-center text-[9px]">
                      <div className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span><span className="font-bold text-slate-600">Fuel / Operating</span></div>
                      <span className="font-black text-slate-900">$2,150.00 <span className="text-slate-400 font-semibold">(55.8%)</span></span>
                    </div>
                    <div className="flex justify-between items-center text-[9px]">
                      <div className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span><span className="font-bold text-slate-600">Maintenance & Repairs</span></div>
                      <span className="font-black text-slate-900">$1,250.00 <span className="text-slate-400 font-semibold">(32.5%)</span></span>
                    </div>
                    <div className="flex justify-between items-center text-[9px]">
                      <div className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-red-500"></span><span className="font-bold text-slate-600">Insurance</span></div>
                      <span className="font-black text-slate-900">$300.00 <span className="text-slate-400 font-semibold">(7.8%)</span></span>
                    </div>
                    <div className="flex justify-between items-center text-[9px]">
                      <div className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span><span className="font-bold text-slate-600">Registration</span></div>
                      <span className="font-black text-slate-900">$100.00 <span className="text-slate-400 font-semibold">(2.6%)</span></span>
                    </div>
                    <div className="flex justify-between items-center text-[9px]">
                      <div className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-slate-500"></span><span className="font-bold text-slate-600">Other</span></div>
                      <span className="font-black text-slate-900">$50.00 <span className="text-slate-400 font-semibold">(1.3%)</span></span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Chart: Monthly Cost Trend */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">MONTHLY COST TREND (FY 2024-2025)</h4>
                  <span className="text-[9px] font-bold text-purple-600 cursor-pointer hover:underline">View Chart →</span>
                </div>
                <div className="relative h-20 w-full mt-2">
                  <div className="absolute left-0 top-0 bottom-4 w-6 flex flex-col justify-between text-[8px] font-bold text-slate-400 text-right pr-1">
                    <span>$800</span>
                    <span>$600</span>
                    <span>$400</span>
                    <span>$200</span>
                    <span>$0</span>
                  </div>
                  <div className="absolute left-6 right-0 top-0 bottom-4 border-l border-b border-slate-200">
                    {/* SVG Line Chart representing the purple trend line */}
                    <svg width="100%" height="100%" preserveAspectRatio="none" viewBox="0 0 100 100" className="overflow-visible">
                      <path d="M 0,80 L 10,70 L 20,85 L 30,50 L 40,65 L 50,45 L 60,60 L 70,55 L 80,48 L 90,52 L 100,55" fill="none" stroke="#8B5CF6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                      <circle cx="80" cy="48" r="3" fill="#fff" stroke="#8B5CF6" strokeWidth="2" />
                    </svg>
                    {/* Tooltip */}
                    <div className="absolute bg-slate-800 text-white text-[8px] font-bold px-1.5 py-0.5 rounded left-[72%] top-[-2px] shadow-lg pointer-events-none whitespace-nowrap">
                      Apr 2025<br/><span className="text-[9px]">$420.00</span>
                    </div>
                  </div>
                  <div className="absolute left-6 right-0 bottom-0 flex justify-between text-[8px] font-bold text-slate-400 pt-1">
                    <span>Jul</span><span>Aug</span><span>Sep</span><span>Oct</span><span>Nov</span><span>Dec</span><span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span><span>May</span><span>Jun</span>
                  </div>
                </div>
              </div>

              {/* Quick Actions & Recent Cost Alerts Row */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex gap-4">
                <div className="flex-1">
                  <h4 className="text-[10px] font-black text-slate-800 uppercase tracking-widest mb-2">QUICK ACTIONS</h4>
                  <div className="space-y-2">
                    {[
                      { icon: <Plus size={12} />, label: 'Add Cost / Expense' },
                      { icon: <Download size={12} />, label: 'Upload Invoice / Receipt' },
                      { icon: <Calendar size={12} />, label: 'Schedule Maintenance' },
                      { icon: <FileText size={12} />, label: 'View Cost Report' },
                      { icon: <FileText size={12} />, label: 'View Depreciation Report' },
                      { icon: <FileSpreadsheet size={12} />, label: 'Export Cost Data' }
                    ].map((act, i) => (
                      <button key={i} className="w-full flex items-center gap-2 text-slate-600 hover:text-purple-600 transition-colors text-[10px] font-bold group cursor-pointer text-left">
                        <span className="text-slate-400 group-hover:text-purple-600">{act.icon}</span>
                        {act.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex-1">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">RECENT COST ALERTS</h4>
                    <span className="text-[9px] font-bold text-purple-600 cursor-pointer hover:underline">View All →</span>
                  </div>
                  <div className="space-y-2">
                    <div className="bg-orange-50 border border-orange-100 p-2 rounded-lg flex items-start gap-2">
                      <AlertTriangle size={12} className="text-orange-500 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-[10px] font-bold text-slate-800 leading-tight hover:text-purple-600 cursor-pointer hover:underline">Hydraulic Pump Repair</div>
                        <div className="text-[9px] text-slate-500 font-semibold flex justify-between w-full pr-1">
                          <span>$858.00</span><span>25 Apr 2025</span>
                        </div>
                      </div>
                    </div>
                    <div className="bg-orange-50 border border-orange-100 p-2 rounded-lg flex items-start gap-2">
                      <AlertTriangle size={12} className="text-orange-500 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-[10px] font-bold text-slate-800 leading-tight hover:text-purple-600 cursor-pointer hover:underline">Service Due Soon</div>
                        <div className="text-[9px] text-slate-500 font-semibold mt-0.5">24 Jun 2025</div>
                      </div>
                    </div>
                    <div className="bg-blue-50 border border-blue-100 p-2 rounded-lg flex items-start gap-2">
                      <Info size={12} className="text-blue-500 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-[10px] font-bold text-slate-800 leading-tight hover:text-purple-600 cursor-pointer hover:underline">Insurance Renewal</div>
                        <div className="text-[9px] text-slate-500 font-semibold mt-0.5">01 Apr 2026</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* DEVELOPER NOTES (For Costs & Depreciation) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mt-6">
            <div className="p-4 border-b border-slate-100 flex items-center gap-2">
              <div className="bg-purple-600 p-1.5 rounded text-white">
                <Code size={14} />
              </div>
              <h3 className="text-[11px] font-black text-purple-700 uppercase tracking-widest">DEVELOPER NOTES - ASSET COSTS & DEPRECIATION</h3>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6 p-4 sm:p-6">
              {/* Col 1 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">1</div> 
                  <span>PURPOSE</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Track all costs, expenses and depreciation.</li>
                  <li className="pl-1">Support financial reporting and tax compliance.</li>
                  <li className="pl-1">Provide clear visibility of asset profitability.</li>
                </ul>
              </div>
              
              {/* Col 2 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">2</div> 
                  <span>KEY FEATURES</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Record recurring and one-off costs.</li>
                  <li className="pl-1">Depreciation calculation (straight line by default).</li>
                  <li className="pl-1">Cost categorisation and trend analysis.</li>
                  <li className="pl-1">Export reports for accounting integration.</li>
                </ul>
              </div>
              
              {/* Col 3 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">3</div> 
                  <span>AUTOMATION & ALERTS</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Auto-calculate depreciation based on rules.</li>
                  <li className="pl-1">Alert for upcoming large expenses.</li>
                  <li className="pl-1">Predict annual cost based on patterns.</li>
                  <li className="pl-1">AI insights for cost optimisation (AI add-on).</li>
                </ul>
              </div>

              {/* Col 4 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">4</div> 
                  <span>PERMISSIONS</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Super Admin: Full access.</li>
                  <li className="pl-1">Admin/Manager: Create, edit, approve.</li>
                  <li className="pl-1">Accounts: View financial data & export.</li>
                  <li className="pl-1">Staff: View assigned asset costs.</li>
                </ul>
              </div>

              {/* Col 5 */}
              <div>
                <h4 className="text-[11px] font-black text-slate-800 mb-3 flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center text-[9px] text-slate-600 border border-slate-200">5</div> 
                  <span>DATA SOURCES</span>
                </h4>
                <ul className="space-y-2 text-[10px] font-semibold text-slate-500 list-disc list-inside marker:text-slate-300">
                  <li className="pl-1">Costs & Expenses module.</li>
                  <li className="pl-1">Maintenance module.</li>
                  <li className="pl-1">Fuel & Usage module.</li>
                  <li className="pl-1">Invoices & Receipts (OCR).</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-slate-50/80 border-t border-slate-100 p-4 flex items-center justify-between">
              <span className="text-[9px] font-bold text-slate-500">All times shown in your local time (AEST)</span>
              <div className="flex items-center gap-2 text-[9px] font-bold text-slate-500">
                Data auto-refreshes every 5 minutes
                <RefreshCw size={10} className="text-slate-400" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* OTHER TABS PLACEHOLDERS */}
      {activeTab !== 'Overview' && activeTab !== 'Specifications' && activeTab !== 'Assignments & History' && activeTab !== 'Costs & Depreciation' && activeTab !== 'Maintenance & Service' && activeTab !== 'Compliance & Documents' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm text-center">
          <div className="w-12 h-12 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center mx-auto mb-3">
            <Layers size={24} />
          </div>
          <h3 className="text-sm font-black text-slate-900 mb-1">{activeTab} Details</h3>
          <p className="text-xs text-slate-500 font-semibold max-w-md mx-auto mb-4">
            Viewing {activeTab.toLowerCase()} records and activity for {asset.fullName} ({asset.id}).
          </p>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-lg border border-emerald-200">
            <CheckCircle size={14} /> All data up to date
          </div>
        </div>
      )}

      {/* EDIT ASSET MODAL OVERLAY */}
      {isEditing && (
        <div className="fixed inset-0 z-[99999] bg-slate-900/60 backdrop-blur-sm flex items-start justify-center pt-16 pb-6 px-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-3xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[82vh]">

            {/* Modal Header */}
            <div className="p-5 border-b border-slate-200 bg-slate-50/50 flex justify-between items-center">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 border border-purple-100 flex items-center justify-center">
                  <Edit size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Edit Asset Details – {asset.id}</h3>
                  <p className="text-xs text-slate-500 font-semibold">Update specifications, category, status, pricing, and notes.</p>
                </div>
              </div>
              <button onClick={() => setIsEditing(false)} className="w-8 h-8 rounded-lg border border-slate-200 text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer">
                <X size={16} />
              </button>
            </div>

            {/* Modal Form Body */}
            <form onSubmit={handleSaveEditAsset} className="p-6 space-y-6 flex-1 overflow-y-auto custom-scrollbar">

              {/* Section 1: Basic Information */}
              <div>
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-3 border-b border-slate-100 pb-1.5 flex items-center gap-2">
                  <Package size={14} className="text-purple-600" /> Basic Information
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Asset ID</label>
                    <input type="text" value={editFormData.id} disabled className="w-full bg-slate-100 border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-500 cursor-not-allowed" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Asset Name</label>
                    <input type="text" value={editFormData.name} onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value, fullName: `${e.target.value} Forklift` })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-200" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Full Name</label>
                    <input type="text" value={editFormData.fullName} onChange={(e) => setEditFormData({ ...editFormData, fullName: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-200" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Category</label>
                    <select value={editFormData.category} onChange={(e) => setEditFormData({ ...editFormData, category: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 cursor-pointer">
                      <option value="Forklifts">Forklifts</option>
                      <option value="Containers">Containers</option>
                      <option value="Material Handling">Material Handling</option>
                      <option value="Power Equipment">Power Equipment</option>
                      <option value="Equipment">Equipment</option>
                      <option value="IT & Devices">IT & Devices</option>
                      <option value="Workshop Equipment">Workshop Equipment</option>
                      <option value="PPE">PPE</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Type</label>
                    <input type="text" value={editFormData.type} onChange={(e) => setEditFormData({ ...editFormData, type: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Make / Model</label>
                    <input type="text" value={editFormData.makeModel} onChange={(e) => setEditFormData({ ...editFormData, makeModel: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Serial Number</label>
                    <input type="text" value={editFormData.serialNo} onChange={(e) => setEditFormData({ ...editFormData, serialNo: e.target.value, serialNumberFull: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Year of Manufacture</label>
                    <input type="text" value={editFormData.year} onChange={(e) => setEditFormData({ ...editFormData, year: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                </div>
              </div>

              {/* Section 2: Branch & Status */}
              <div>
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-3 border-b border-slate-100 pb-1.5 flex items-center gap-2">
                  <Building size={14} className="text-purple-600" /> Branch, Location & Status
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Branch</label>
                    <select value={editFormData.branch} onChange={(e) => setEditFormData({ ...editFormData, branch: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 cursor-pointer">
                      <option value="Sydney Head Office">Sydney Head Office</option>
                      <option value="Yard - Sydney HO">Yard - Sydney HO</option>
                      <option value="Melbourne Depot">Melbourne Depot</option>
                      <option value="Brisbane Branch">Brisbane Branch</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Current Location</label>
                    <input type="text" value={editFormData.currentLocation} onChange={(e) => setEditFormData({ ...editFormData, currentLocation: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Assigned To</label>
                    <input type="text" value={editFormData.assignedTo} onChange={(e) => setEditFormData({ ...editFormData, assignedTo: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Status</label>
                    <select value={editFormData.status} onChange={(e) => setEditFormData({ ...editFormData, status: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 cursor-pointer">
                      <option value="Active">Active</option>
                      <option value="Maintenance">Maintenance</option>
                      <option value="Out of Service">Out of Service</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Condition</label>
                    <select value={editFormData.condition} onChange={(e) => setEditFormData({ ...editFormData, condition: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 cursor-pointer">
                      <option value="Good">Good</option>
                      <option value="Fair">Fair</option>
                      <option value="Poor">Poor</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Usage Type</label>
                    <input type="text" value={editFormData.usageType} onChange={(e) => setEditFormData({ ...editFormData, usageType: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                </div>
              </div>

              {/* Section 3: Pricing & Financials */}
              <div>
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-3 border-b border-slate-100 pb-1.5 flex items-center gap-2">
                  <DollarSign size={14} className="text-purple-600" /> Pricing & Financials
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Purchase Date</label>
                    <input type="text" value={editFormData.purchaseDate} onChange={(e) => setEditFormData({ ...editFormData, purchaseDate: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Purchase Price</label>
                    <input type="text" value={editFormData.purchasePrice} onChange={(e) => setEditFormData({ ...editFormData, purchasePrice: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Current Book Value</label>
                    <input type="text" value={editFormData.bookValue} onChange={(e) => setEditFormData({ ...editFormData, bookValue: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Supplier</label>
                    <input type="text" value={editFormData.supplier} onChange={(e) => setEditFormData({ ...editFormData, supplier: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Operating Hours</label>
                    <input type="text" value={editFormData.operatingHours} onChange={(e) => setEditFormData({ ...editFormData, operatingHours: e.target.value, odometer: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Warranty Expiry</label>
                    <input type="text" value={editFormData.warrantyExpiry} onChange={(e) => setEditFormData({ ...editFormData, warrantyExpiry: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                  </div>
                </div>
              </div>

              {/* Section 4: Description & Notes */}
              <div>
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest mb-3 border-b border-slate-100 pb-1.5 flex items-center gap-2">
                  <FileText size={14} className="text-purple-600" /> Description & Notes
                </h4>
                <div className="space-y-4">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Asset Description</label>
                    <textarea rows={3} value={editFormData.description} onChange={(e) => setEditFormData({ ...editFormData, description: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg p-3 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 resize-none" />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Operator / Internal Notes</label>
                    <textarea rows={2} value={editFormData.notes} onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg p-3 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 resize-none" />
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <button type="button" onClick={() => setIsEditing(false)} className="px-4 py-2 border border-slate-200 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer">
                  Cancel
                </button>
                <div className="flex items-center gap-3">
                  <button type="button" onClick={() => setEditFormData({ ...asset })} className="px-4 py-2 border border-purple-200 rounded-lg text-xs font-bold text-purple-700 hover:bg-purple-50 transition-colors cursor-pointer">
                    Reset Fields
                  </button>
                  <button type="submit" className="px-5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer">
                    <Check size={14} /> Save Changes
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 1. ASSIGN / TRANSFER ASSET MODAL */}
      {isAssignModalOpen && (
        <div className="fixed inset-0 z-[99999] bg-slate-900/60 backdrop-blur-sm flex items-start justify-center pt-16 pb-6 px-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-200 flex flex-col">
            <div className="p-5 border-b border-slate-200 bg-slate-50/50 flex justify-between items-center">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 border border-purple-100 flex items-center justify-center">
                  <User size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Assign / Transfer Asset – {asset.id}</h3>
                  <p className="text-xs text-slate-500 font-semibold">Reassign asset to a new branch, location or operator.</p>
                </div>
              </div>
              <button onClick={() => setIsAssignModalOpen(false)} className="w-8 h-8 rounded-lg border border-slate-200 text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center cursor-pointer">
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleConfirmTransfer} className="p-6 space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Target Branch</label>
                <select value={transferForm.branch} onChange={(e) => setTransferForm({ ...transferForm, branch: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 cursor-pointer">
                  <option value="Sydney Head Office">Sydney Head Office</option>
                  <option value="Yard - Sydney HO">Yard - Sydney HO</option>
                  <option value="Melbourne Depot">Melbourne Depot</option>
                  <option value="Brisbane Branch">Brisbane Branch</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Specific Location / Bay</label>
                <input type="text" value={transferForm.currentLocation} onChange={(e) => setTransferForm({ ...transferForm, currentLocation: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" placeholder="e.g. Warehouse 2 - Bay C1" />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Assigned Operator / Unit</label>
                <select value={transferForm.assignedTo} onChange={(e) => setTransferForm({ ...transferForm, assignedTo: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 cursor-pointer">
                  <option value="Warehouse 1">Warehouse 1 (General)</option>
                  <option value="Mike Thompson">Mike Thompson (Driver)</option>
                  <option value="James Patel">James Patel (Fleet Tech)</option>
                  <option value="Robert Taylor">Robert Taylor (Supervisor)</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Transfer Notes / Reason</label>
                <textarea rows={2} value={transferForm.notes} onChange={(e) => setTransferForm({ ...transferForm, notes: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 resize-none" placeholder="Reason for transfer or assignment..." />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                <button type="button" onClick={() => setIsAssignModalOpen(false)} className="px-4 py-2 border border-slate-200 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer">
                  <Check size={14} /> Confirm Transfer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. SCHEDULE MAINTENANCE MODAL */}
      {isMaintenanceModalOpen && (
        <div className="fixed inset-0 z-[99999] bg-slate-900/60 backdrop-blur-sm flex items-start justify-center pt-16 pb-6 px-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-200 flex flex-col">
            <div className="p-5 border-b border-slate-200 bg-slate-50/50 flex justify-between items-center">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 border border-amber-100 flex items-center justify-center">
                  <Wrench size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Schedule Maintenance – {asset.id}</h3>
                  <p className="text-xs text-slate-500 font-semibold">Book a preventative service or repair for this asset.</p>
                </div>
              </div>
              <button onClick={() => setIsMaintenanceModalOpen(false)} className="w-8 h-8 rounded-lg border border-slate-200 text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center cursor-pointer">
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleConfirmMaintenance} className="p-6 space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Service Type</label>
                <select value={maintForm.serviceType} onChange={(e) => setMaintForm({ ...maintForm, serviceType: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 cursor-pointer">
                  <option value="Oil & Filter Change">Oil & Filter Change</option>
                  <option value="Hydraulic System Check">Hydraulic System Check</option>
                  <option value="Annual Full Inspection">Annual Full Inspection</option>
                  <option value="Brake & Tire Service">Brake & Tire Service</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Scheduled Date</label>
                  <input type="text" value={maintForm.date} onChange={(e) => setMaintForm({ ...maintForm, date: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Technician / Provider</label>
                  <input type="text" value={maintForm.provider} onChange={(e) => setMaintForm({ ...maintForm, provider: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500" />
                </div>
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Service Instructions</label>
                <textarea rows={2} value={maintForm.instructions} onChange={(e) => setMaintForm({ ...maintForm, instructions: e.target.value })} className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 outline-none focus:border-purple-500 resize-none" />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                <button type="button" onClick={() => setIsMaintenanceModalOpen(false)} className="px-4 py-2 border border-slate-200 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer">
                  <Check size={14} /> Schedule Service
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. PRINT LABEL / QR MODAL */}
      {isPrintQRModalOpen && (
        <div className="fixed inset-0 z-[99999] bg-slate-900/60 backdrop-blur-sm flex items-start justify-center pt-16 pb-6 px-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200 flex flex-col">
            <div className="p-5 border-b border-slate-200 bg-slate-50/50 flex justify-between items-center">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 border border-purple-100 flex items-center justify-center">
                  <QrCode size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Print Asset QR Tag – {asset.id}</h3>
                  <p className="text-xs text-slate-500 font-semibold">Generate printable barcode label & QR tag.</p>
                </div>
              </div>
              <button onClick={() => setIsPrintQRModalOpen(false)} className="w-8 h-8 rounded-lg border border-slate-200 text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center cursor-pointer">
                <X size={16} />
              </button>
            </div>

            <div className="p-6 text-center space-y-4">
              <div className="border-2 border-dashed border-slate-300 rounded-2xl p-6 bg-slate-50 max-w-xs mx-auto space-y-3 shadow-inner">
                <div className="text-[10px] font-black text-purple-700 uppercase tracking-widest">HERO LOGISTICS • ASSET TAG</div>
                <div className="w-24 h-24 bg-white border border-slate-200 rounded-xl mx-auto flex items-center justify-center p-2 shadow-sm">
                  <QrCode size={72} className="text-slate-900" />
                </div>
                <div className="text-sm font-black text-slate-900 tracking-tight">{asset.id}</div>
                <div className="text-xs font-bold text-slate-700">{asset.fullName}</div>
                <div className="text-[10px] text-slate-500 font-semibold">{asset.branch}</div>
              </div>

              <div className="flex justify-between items-center text-xs font-semibold text-slate-600 pt-2">
                <span>Label Format: <b>4" x 2" Standard Heavy Duty</b></span>
                <span>Quantity: <b>1 Tag</b></span>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
                <button type="button" onClick={() => setIsPrintQRModalOpen(false)} className="px-4 py-2 border border-slate-200 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer">Cancel</button>
                <button type="button" onClick={handlePrintAction} className="px-5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer">
                  <Download size={14} /> Print Asset Tag
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. DEACTIVATE ASSET MODAL */}
      {isDeactivateModalOpen && (
        <div className="fixed inset-0 z-[99999] bg-slate-900/60 backdrop-blur-sm flex items-start justify-center pt-16 pb-6 px-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200 flex flex-col">
            <div className="p-5 border-b border-rose-100 bg-rose-50/40 flex justify-between items-center">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 border border-rose-200 flex items-center justify-center">
                  <AlertTriangle size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-rose-900">Deactivate Asset – {asset.id}</h3>
                  <p className="text-xs text-rose-600 font-semibold">Mark asset as Out of Service or Retired.</p>
                </div>
              </div>
              <button onClick={() => setIsDeactivateModalOpen(false)} className="w-8 h-8 rounded-lg border border-slate-200 text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center cursor-pointer">
                <X size={16} />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-600 font-medium leading-relaxed">
                Are you sure you want to deactivate <b>{asset.fullName} ({asset.id})</b>? This will change its status to <b>Out of Service</b> and unassign it from current operations.
              </p>

              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">Reason for Deactivation</label>
                <select value={deactivateReason} onChange={(e) => setDeactivateReason(e.target.value)} className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 outline-none focus:border-rose-500 cursor-pointer">
                  <option value="Scheduled Retirement / End of Life">Scheduled Retirement / End of Life</option>
                  <option value="Major Breakdown / Uneconomical to Repair">Major Breakdown / Uneconomical to Repair</option>
                  <option value="Sold to Third Party">Sold to Third Party</option>
                  <option value="Transferred Out of Network">Transferred Out of Network</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                <button type="button" onClick={() => setIsDeactivateModalOpen(false)} className="px-4 py-2 border border-slate-200 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer">Cancel</button>
                <button type="button" onClick={handleConfirmDeactivate} className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer">
                  Confirm Deactivation
                </button>
              </div>
            </div>
          </div>
        </div>
      )}



      {/* VIEW ASSIGNMENT DETAILS MODAL */}
      {viewAssignmentModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setViewAssignmentModal(null)} />
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative z-10 border border-slate-200">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-[10px] font-black text-purple-700 bg-purple-50 border border-purple-200 px-2.5 py-1 rounded-md uppercase tracking-wider">{viewAssignmentModal.id}</span>
                <h3 className="text-lg font-black text-slate-900 mt-2">Assignment Details</h3>
              </div>
              <button onClick={() => setViewAssignmentModal(null)} className="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-sm cursor-pointer">✕</button>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-5">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Assigned To</span>
                <span className="text-xs font-bold text-slate-900">{viewAssignmentModal.assignedTo}</span>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Status</span>
                <span className={`text-xs font-bold ${viewAssignmentModal.status === 'Current' ? 'text-emerald-600' : 'text-blue-600'}`}>{viewAssignmentModal.status}</span>
              </div>
            </div>

            <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200 text-xs mb-5">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Branch & Location:</span>
                <span className="font-bold text-slate-900 text-right whitespace-pre-line">{viewAssignmentModal.branchLocation}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Purpose:</span>
                <span className="font-bold text-slate-900 text-right whitespace-pre-line">{viewAssignmentModal.purpose}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Assigned By:</span>
                <span className="font-bold text-slate-900">{viewAssignmentModal.assignedBy}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">From Date:</span>
                <span className="font-bold text-slate-900 text-right whitespace-pre-line">{viewAssignmentModal.fromDate}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">To Date:</span>
                <span className="font-bold text-slate-900 text-right whitespace-pre-line">{viewAssignmentModal.toDate}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-semibold">Duration:</span>
                <span className="font-bold text-slate-900 text-right whitespace-pre-line">{viewAssignmentModal.duration}</span>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button onClick={() => setViewAssignmentModal(null)} className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all cursor-pointer">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW COST DETAILS MODAL */}
      {viewCostModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setViewCostModal(null)} />
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative z-10 border border-slate-200">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className={`text-[10px] font-black px-2.5 py-1 rounded-md uppercase tracking-wider ${viewCostModal.color === 'purple' ? 'bg-purple-50 text-purple-700 border border-purple-200' : viewCostModal.color === 'emerald' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : viewCostModal.color === 'blue' ? 'bg-blue-50 text-blue-700 border border-blue-200' : viewCostModal.color === 'orange' ? 'bg-orange-50 text-orange-700 border border-orange-200' : 'bg-slate-100 text-slate-700 border border-slate-200'}`}>
                  {viewCostModal.category}
                </span>
                <h3 className="text-lg font-black text-slate-900 mt-2">{viewCostModal.desc}</h3>
                <p className="text-xs text-slate-500 font-semibold mt-0.5">Ref: {viewCostModal.ref}</p>
              </div>
              <button onClick={() => setViewCostModal(null)} className="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-sm cursor-pointer">✕</button>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-5">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Amount</span>
                <span className="text-xs font-bold text-slate-900">{viewCostModal.amount}</span>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Tax</span>
                <span className="text-xs font-bold text-slate-500">{viewCostModal.tax}</span>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Total</span>
                <span className="text-xs font-black text-purple-700">{viewCostModal.total}</span>
              </div>
            </div>

            <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200 text-xs mb-5">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Date:</span>
                <span className="font-bold text-slate-900">{viewCostModal.date}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Cost Type:</span>
                <span className="font-bold text-slate-900">{viewCostModal.type}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Location / Branch:</span>
                <span className="font-bold text-slate-900">{viewCostModal.loc}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-semibold">Invoice Ref:</span>
                <span className="font-bold text-slate-900">{viewCostModal.ref}</span>
              </div>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-100">
              <button
                onClick={() => { triggerToast('Invoice Downloaded', `Downloading invoice ${viewCostModal.ref}`); setViewCostModal(null); }}
                className="px-4 py-2 bg-purple-50 text-purple-700 hover:bg-purple-100 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2"
              >
                📄 Download Invoice
              </button>
              <button onClick={() => setViewCostModal(null)} className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all cursor-pointer">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT ASSIGNMENT MODAL */}
      {editAssignmentModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setEditAssignmentModal(null)} />
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative z-10 border border-slate-200">
            <div className="flex justify-between items-center pb-4 border-b border-slate-100 mb-5">
              <div>
                <h3 className="text-lg font-black text-slate-900">Edit Assignment Details</h3>
                <p className="text-xs text-slate-500 font-semibold mt-0.5">Ref: {editAssignmentModal.id}</p>
              </div>
              <button onClick={() => setEditAssignmentModal(null)} className="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-sm cursor-pointer">✕</button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                setAssignmentsList(prev => prev.map((item, i) => i === editAssignmentModal.index ? editAssignmentModal : item));
                triggerToast('Assignment Updated', `Saved changes for ${editAssignmentModal.id}`);
                setEditAssignmentModal(null);
              }}
              className="space-y-4 text-xs font-semibold text-slate-700"
            >
              <div>
                <label className="block text-slate-500 font-bold mb-1">Assigned To</label>
                <input
                  type="text"
                  value={editAssignmentModal.assignedTo}
                  onChange={(e) => setEditAssignmentModal({ ...editAssignmentModal, assignedTo: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Branch / Location</label>
                  <input
                    type="text"
                    value={editAssignmentModal.branchLocation}
                    onChange={(e) => setEditAssignmentModal({ ...editAssignmentModal, branchLocation: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Status</label>
                  <select
                    value={editAssignmentModal.status}
                    onChange={(e) => setEditAssignmentModal({ ...editAssignmentModal, status: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900 bg-white"
                  >
                    <option>Current</option>
                    <option>Completed</option>
                    <option>Pending</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-500 font-bold mb-1">Purpose</label>
                <input
                  type="text"
                  value={editAssignmentModal.purpose}
                  onChange={(e) => setEditAssignmentModal({ ...editAssignmentModal, purpose: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditAssignmentModal(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md shadow-purple-600/20"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT MAINTENANCE TASK MODAL */}
      {editMaintTaskModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setEditMaintTaskModal(null)} />
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative z-10 border border-slate-200">
            <div className="flex justify-between items-center pb-4 border-b border-slate-100 mb-5">
              <div>
                <h3 className="text-lg font-black text-slate-900">Edit Maintenance Task</h3>
                <p className="text-xs text-slate-500 font-semibold mt-0.5">{editMaintTaskModal.task}</p>
              </div>
              <button onClick={() => setEditMaintTaskModal(null)} className="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-sm cursor-pointer">✕</button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                setMaintTasksList(prev => prev.map((item, i) => i === editMaintTaskModal.index ? editMaintTaskModal : item));
                triggerToast('Task Updated', `Updated maintenance task "${editMaintTaskModal.task}"`);
                setEditMaintTaskModal(null);
              }}
              className="space-y-4 text-xs font-semibold text-slate-700"
            >
              <div>
                <label className="block text-slate-500 font-bold mb-1">Task Title</label>
                <input
                  type="text"
                  value={editMaintTaskModal.task}
                  onChange={(e) => setEditMaintTaskModal({ ...editMaintTaskModal, task: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Type</label>
                  <select
                    value={editMaintTaskModal.type}
                    onChange={(e) => setEditMaintTaskModal({ ...editMaintTaskModal, type: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900 bg-white"
                  >
                    <option>Service</option>
                    <option>Inspection</option>
                    <option>Repair</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Priority</label>
                  <select
                    value={editMaintTaskModal.priority}
                    onChange={(e) => setEditMaintTaskModal({ ...editMaintTaskModal, priority: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900 bg-white"
                  >
                    <option>High</option>
                    <option>Medium</option>
                    <option>Low</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Frequency</label>
                  <input
                    type="text"
                    value={editMaintTaskModal.freq}
                    onChange={(e) => setEditMaintTaskModal({ ...editMaintTaskModal, freq: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Assigned To</label>
                  <input
                    type="text"
                    value={editMaintTaskModal.assigned}
                    onChange={(e) => setEditMaintTaskModal({ ...editMaintTaskModal, assigned: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-500 font-bold mb-1">Status</label>
                <select
                  value={editMaintTaskModal.status}
                  onChange={(e) => setEditMaintTaskModal({ ...editMaintTaskModal, status: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900 bg-white"
                >
                  <option>Due Soon</option>
                  <option>Scheduled</option>
                  <option>Completed</option>
                  <option>Overdue</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditMaintTaskModal(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md shadow-purple-600/20"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT COST RECORD MODAL */}
      {editCostModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setEditCostModal(null)} />
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative z-10 border border-slate-200">
            <div className="flex justify-between items-center pb-4 border-b border-slate-100 mb-5">
              <div>
                <h3 className="text-lg font-black text-slate-900">Edit Cost / Expense Record</h3>
                <p className="text-xs text-slate-500 font-semibold mt-0.5">Invoice Ref: {editCostModal.ref}</p>
              </div>
              <button onClick={() => setEditCostModal(null)} className="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-sm cursor-pointer">✕</button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                setCostsList(prev => prev.map((item, i) => i === editCostModal.index ? editCostModal : item));
                triggerToast('Expense Updated', `Updated cost record ${editCostModal.ref}`);
                setEditCostModal(null);
              }}
              className="space-y-4 text-xs font-semibold text-slate-700"
            >
              <div>
                <label className="block text-slate-500 font-bold mb-1">Description</label>
                <input
                  type="text"
                  value={editCostModal.desc}
                  onChange={(e) => setEditCostModal({ ...editCostModal, desc: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Category</label>
                  <select
                    value={editCostModal.category}
                    onChange={(e) => setEditCostModal({ ...editCostModal, category: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900 bg-white"
                  >
                    <option>Maintenance</option>
                    <option>Operating</option>
                    <option>Insurance</option>
                    <option>Registration</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Cost Type</label>
                  <input
                    type="text"
                    value={editCostModal.type}
                    onChange={(e) => setEditCostModal({ ...editCostModal, type: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Amount (AUD)</label>
                  <input
                    type="text"
                    value={editCostModal.amount}
                    onChange={(e) => setEditCostModal({ ...editCostModal, amount: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Total (AUD)</label>
                  <input
                    type="text"
                    value={editCostModal.total}
                    onChange={(e) => setEditCostModal({ ...editCostModal, total: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Invoice Ref</label>
                  <input
                    type="text"
                    value={editCostModal.ref}
                    onChange={(e) => setEditCostModal({ ...editCostModal, ref: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Branch / Location</label>
                  <input
                    type="text"
                    value={editCostModal.loc}
                    onChange={(e) => setEditCostModal({ ...editCostModal, loc: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditCostModal(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md shadow-purple-600/20"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT DOCUMENT DETAILS MODAL */}
      {editDocModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setEditDocModal(null)} />
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative z-10 border border-slate-200">
            <div className="flex justify-between items-center pb-4 border-b border-slate-100 mb-5">
              <div>
                <h3 className="text-lg font-black text-slate-900">Edit Document Details</h3>
                <p className="text-xs text-slate-500 font-semibold mt-0.5">Update metadata for {editDocModal.file}</p>
              </div>
              <button onClick={() => setEditDocModal(null)} className="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-sm cursor-pointer">✕</button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                setDocumentsList(prev => prev.map((item, i) => i === editDocModal.index ? editDocModal : item));
                triggerToast('Document Updated', `Saved changes for "${editDocModal.name}"`);
                setEditDocModal(null);
              }}
              className="space-y-4 text-xs font-semibold text-slate-700"
            >
              <div>
                <label className="block text-slate-500 font-bold mb-1">Document Name</label>
                <input
                  type="text"
                  value={editDocModal.name}
                  onChange={(e) => setEditDocModal({ ...editDocModal, name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Category</label>
                  <select
                    value={editDocModal.category}
                    onChange={(e) => setEditDocModal({ ...editDocModal, category: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900 bg-white"
                  >
                    <option>Registration</option>
                    <option>Maintenance</option>
                    <option>Inspection</option>
                    <option>Licence</option>
                    <option>Insurance</option>
                    <option>Compliance</option>
                    <option>Warranty</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Document Type</label>
                  <input
                    type="text"
                    value={editDocModal.type}
                    onChange={(e) => setEditDocModal({ ...editDocModal, type: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Issue Date</label>
                  <input
                    type="text"
                    value={editDocModal.issueDate}
                    onChange={(e) => setEditDocModal({ ...editDocModal, issueDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Expiry Date</label>
                  <input
                    type="text"
                    value={editDocModal.expiryDate}
                    onChange={(e) => setEditDocModal({ ...editDocModal, expiryDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Status</label>
                  <select
                    value={editDocModal.status}
                    onChange={(e) => setEditDocModal({ ...editDocModal, status: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900 bg-white"
                  >
                    <option>Active</option>
                    <option>Expired</option>
                    <option>Inactive</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 font-bold mb-1">Expiry Status</label>
                  <select
                    value={editDocModal.expiryStatus}
                    onChange={(e) => setEditDocModal({ ...editDocModal, expiryStatus: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900 bg-white"
                  >
                    <option>Compliant</option>
                    <option>Expiring Soon</option>
                    <option>Expired</option>
                    <option>Not Required</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-500 font-bold mb-1">Uploaded By</label>
                <input
                  type="text"
                  value={editDocModal.uploader}
                  onChange={(e) => setEditDocModal({ ...editDocModal, uploader: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none focus:border-purple-500 font-bold text-slate-900"
                />
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditDocModal(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md shadow-purple-600/20"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VIEW DOCUMENT DETAILS MODAL */}
      {viewDocModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setViewDocModal(null)} />
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative z-10 border border-slate-200">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-[10px] font-black text-purple-700 bg-purple-50 border border-purple-200 px-2.5 py-1 rounded-md uppercase tracking-wider">{viewDocModal.category}</span>
                <h3 className="text-lg font-black text-slate-900 mt-2">{viewDocModal.name}</h3>
                <p className="text-xs text-slate-500 font-semibold mt-0.5">📄 {viewDocModal.file}</p>
              </div>
              <button onClick={() => setViewDocModal(null)} className="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-sm cursor-pointer">✕</button>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-5">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Status</span>
                <span className={`text-xs font-bold ${viewDocModal.status === 'Active' ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {viewDocModal.status}
                </span>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Expiry Status</span>
                <span className={`text-xs font-bold ${viewDocModal.expiryStatus === 'Compliant' ? 'text-emerald-600' : viewDocModal.expiryStatus === 'Expiring Soon' ? 'text-amber-600' : 'text-rose-600'}`}>
                  {viewDocModal.expiryStatus}
                </span>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Doc Type</span>
                <span className="text-xs font-bold text-slate-900">{viewDocModal.type}</span>
              </div>
            </div>

            <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200 text-xs mb-5">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Issue Date:</span>
                <span className="font-bold text-slate-900">{viewDocModal.issueDate}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Expiry Date:</span>
                <span className="font-bold text-slate-900">{viewDocModal.expiryDate}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Uploaded By:</span>
                <span className="font-bold text-slate-900">{viewDocModal.uploader}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-semibold">Upload Date:</span>
                <span className="font-bold text-slate-900">{viewDocModal.uploadDate}</span>
              </div>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-100">
              <button
                onClick={() => { triggerToast('Document Downloaded', `Downloading file ${viewDocModal.file}`); setViewDocModal(null); }}
                className="px-4 py-2 bg-purple-50 text-purple-700 hover:bg-purple-100 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2"
              >
                📥 Download File
              </button>
              <button onClick={() => setViewDocModal(null)} className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all cursor-pointer">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW MAINTENANCE TASK DETAILS MODAL */}
      {viewMaintTaskModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setViewMaintTaskModal(null)} />
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative z-10 border border-slate-200">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className={`text-[10px] font-black px-2.5 py-1 rounded-md uppercase tracking-wider ${viewMaintTaskModal.type === 'Service' ? 'bg-purple-50 text-purple-700 border border-purple-200' : 'bg-amber-50 text-amber-700 border border-amber-200'}`}>
                  {viewMaintTaskModal.type}
                </span>
                <h3 className="text-lg font-black text-slate-900 mt-2">{viewMaintTaskModal.task}</h3>
                <p className="text-xs text-slate-500 font-medium mt-0.5">{viewMaintTaskModal.desc}</p>
              </div>
              <button onClick={() => setViewMaintTaskModal(null)} className="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-sm cursor-pointer">✕</button>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-5">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Priority</span>
                <span className={`text-xs font-bold ${viewMaintTaskModal.priority === 'High' ? 'text-rose-600' : viewMaintTaskModal.priority === 'Medium' ? 'text-amber-600' : 'text-emerald-600'}`}>
                  {viewMaintTaskModal.priority}
                </span>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Status</span>
                <span className={`text-xs font-bold ${viewMaintTaskModal.status === 'Due Soon' ? 'text-amber-600' : viewMaintTaskModal.status === 'Scheduled' ? 'text-blue-600' : 'text-emerald-600'}`}>
                  {viewMaintTaskModal.status}
                </span>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Frequency</span>
                <span className="text-xs font-bold text-slate-900">{viewMaintTaskModal.freq}</span>
              </div>
            </div>

            <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200 text-xs mb-5">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Last Performed:</span>
                <span className="font-bold text-slate-900">{viewMaintTaskModal.lastDate} {viewMaintTaskModal.lastHrs ? `(@ ${viewMaintTaskModal.lastHrs})` : ''}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Next Due Date:</span>
                <span className="font-bold text-slate-900">{viewMaintTaskModal.nextDate} {viewMaintTaskModal.nextHrs ? `(@ ${viewMaintTaskModal.nextHrs})` : ''}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Days Remaining:</span>
                <span className="font-bold text-amber-600">{viewMaintTaskModal.daysRemaining}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-semibold">Assigned To:</span>
                <span className="font-bold text-slate-900">{viewMaintTaskModal.assigned} {viewMaintTaskModal.role ? `(${viewMaintTaskModal.role})` : ''}</span>
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button onClick={() => setViewMaintTaskModal(null)} className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all cursor-pointer">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* TOAST BANNER */}
      {showToast && (
        <div className="fixed bottom-6 right-6 z-[10000] bg-slate-900 text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-slate-700 flex items-center gap-3 animate-bounce">
          <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">✓</div>
          <div>
            <div className="text-xs font-black text-white">{toastMessage.title}</div>
            <div className="text-[11px] font-semibold text-slate-300">{toastMessage.desc}</div>
          </div>
        </div>
      )}

    </div>
  );
}
